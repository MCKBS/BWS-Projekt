package bws.gui.main;

import bws.gui.StartseiteGUI;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * @author Mert-Can Kocabas
 */
public class Main extends Application {

    /**
     * 'Buehne' fuer unsere Anwendung.
     */
    private static final Stage primaryStage = new Stage();

    /**
     * Startet das Hauptfenster der Anwendung.
     *
     * @author Mert-Can Kocabas
     */
    @Override
    public void start(Stage primaryStage) {
        StartseiteGUI startseite = new StartseiteGUI();
        startseite.start();
    }

    /**
     * Einstiegspunkt in die Ausfuehrung der Anwendung.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * @author Mert-Can Kocabas
     * @return Gibt die primaryStage zurueck.
     */
    public static Stage getPrimaryStage() {
        return primaryStage;
    }
}
