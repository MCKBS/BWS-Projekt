package bws.gui;

import static bws.gui.StartseiteGUI.logo;

import bws.gui.main.Main;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;

import javafx.stage.Stage;
import javafx.stage.Window;

/**
 * @author Franziska Wuttig
 */
public class LevelAuswahlGUI {

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * Button zur Auswahl des Levels Weltkarte.
     */
    private Button weltButton;

    /**
     * Button zur Auswahl des Levels Europakarte.
     */
    private Button europaButton;

    /**
     * Button zur Auswahl des Levels Deutschlandkarte.
     */
    private Button deutschlandButton;

    /**
     * Button um zurueck zur Startseite zu gelangen.
     */
    private Button zurueckButton;

    /**
     * GridPane, welches den Inhalt der Kopfzeile beinhaltet.
     */
    private GridPane gridPaneHeaderRow;

    /**
     * GridPane, welches die Buttons zur Level auswahl beinhaltet.
     */
    private GridPane gridPaneCenter;

    /**
     * GridPane, welches den Inhalt der Fußzeile beinhaltet.
     */
    private GridPane gridPaneFooterRow;

    /**
     * Label zur Darstellung des Seitentitels.
     */
    private Label labelTitel;

    /**
     * Konstruktor der Klasse.
     *
     * @author Franziska Wuttig
     */
    public LevelAuswahlGUI() {
        initLabel();
        initButtons();
        initGridPaneHeaderRow();
        initGridPaneCenter();
        initGridFooterGrid();
        initBorderPane();

        weltButtonEvent();
        europaButtonEvent();
        deutschlandButtonEvent();
        zurueckButtonEvent();
    }

    /**
     * Initialisierung der Labels.
     *
     * @author Franziska Wuttig
     */
    private void initLabel() {
        labelTitel = new Label("Level auswählen");
    }

    /**
     * Initialisierung der Buttons.
     *
     * @author Franziska Wuttig
     */
    private void initButtons() {
        weltButton = new Button("Weltkarte");
        europaButton = new Button("Europakarte");
        deutschlandButton = new Button("Deutschlandkarte");
        zurueckButton = new Button("Zurück");
    }

    private void initGridPaneHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);
        gridPaneHeaderRow.setStyle("-fx-font-size: 20pt;");

        gridPaneHeaderRow.setAlignment(Pos.CENTER);
        gridPaneHeaderRow.setHalignment(logo, HPos.CENTER);

        gridPaneHeaderRow.add(logo, 0, 0);
        gridPaneHeaderRow.add(labelTitel, 0, 1);
    }

    /**
     * Initialisierung des Center-Grid. Die Darstellung des Grids wird angepasst
     * und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initGridPaneCenter() {
        gridPaneCenter = new GridPane();

        gridPaneCenter.setPadding(new Insets(10, 10, 10, 15));
        gridPaneCenter.setHgap(5);
        gridPaneCenter.setVgap(5);

        gridPaneCenter.setAlignment(Pos.CENTER);

        weltButton.setMaxWidth(Double.MAX_VALUE);
        europaButton.setMaxWidth(Double.MAX_VALUE);
        deutschlandButton.setMaxWidth(Double.MAX_VALUE);

        gridPaneCenter.add(weltButton, 0, 0);
        gridPaneCenter.add(europaButton, 0, 1);
        gridPaneCenter.add(deutschlandButton, 0, 2);
    }

    /**
     * Initialisierung des Fußleisten-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initGridFooterGrid() {
        gridPaneFooterRow = new GridPane();

        gridPaneFooterRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneFooterRow.setHgap(5);
        gridPaneFooterRow.setVgap(5);

        gridPaneFooterRow.setAlignment(Pos.CENTER);

        gridPaneFooterRow.add(zurueckButton, 0, 0);
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(gridPaneCenter);
        borderPane.setBottom(gridPaneFooterRow);

        borderPane.setPadding(new Insets(15, 15, 15, 15));
        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Weiterleitung zum Spielfenster mit der Welt-Spielkarte.
     *
     * @author Mert-Can Kocabas
     */
    private void weltButtonEvent() {
        weltButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                SpielfensterGUI spielfenster = new SpielfensterGUI();
                String url;
                url = this.getClass().getResource("/bws/resources/leaflet/weltMapSpiel.html").toExternalForm();
                spielfenster.getWebEngine().load(url);
                if (spielfenster.fillFragenList("Weltkarte")) {
                    Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                    stage.close();

                    spielfenster.start();
                } else {
                    showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Nicht genügend Fragen vorhanden", "Es müssen mindestens 10 Fragen zu der Karte existieren.");
                }
            }
        });
    }

    /**
     * Weiterleitung zum Spielfenster mit der Europa-Spielkarte.
     *
     * @author Mert-Can Kocabas
     */
    private void europaButtonEvent() {
        europaButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                SpielfensterGUI spielfenster = new SpielfensterGUI();
                String url;
                url = this.getClass().getResource("/bws/resources/leaflet/europaMapSpiel.html").toExternalForm();
                spielfenster.getWebEngine().load(url);
                if (spielfenster.fillFragenList("Europakarte")) {
                    Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                    stage.close();

                    spielfenster.start();
                } else {
                    showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Nicht genügend Fragen vorhanden", "Es müssen mindestens 10 Fragen zu der Karte existieren.");
                }
            }
        });
    }

    /**
     * Weiterleitung zum Spielfenster mit der Deutschland-Spielkarte.
     *
     * @author Mert-Can Kocabas
     */
    private void deutschlandButtonEvent() {
        deutschlandButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                SpielfensterGUI spielfenster = new SpielfensterGUI();
                String url;
                url = this.getClass().getResource("/bws/resources/leaflet/deutschlandMapSpiel.html").toExternalForm();
                spielfenster.getWebEngine().load(url);
                if (spielfenster.fillFragenList("Deutschlandkarte")) {
                    Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                    stage.close();

                    spielfenster.start();
                } else {
                    showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Nicht genügend Fragen vorhanden", "Es müssen mindestens 10 Fragen zu der Karte existieren.");
                }
            }
        });
    }

    /**
     * Weiterleitung zurück zur Startseite.
     *
     * @author Mert-Can Kocabas
     */
    private void zurueckButtonEvent() {
        zurueckButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                StartseiteGUI startseite = new StartseiteGUI();
                startseite.start();
            }
        });
    }

    /**
     * Alert wird dargestellt. Dabei wird dem Alert verschiedene Eigenschaften
     * festgelegt.
     *
     * @author Franziska Wuttig
     * @param alertType Gibt den Typ des Alerts an.
     * @param owner Gibt den 'Besitzer'/Zugehoerigkeit des Alerts an.
     * @param title Gibt den Titel des Alerts an.
     * @param message Gibt die Nachricht an, die angezeigt werden soll.
     */
    private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);

        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    /**
     * Zeigt das Fenster an.
     *
     * @author Frnziska Wuttig
     */
    public void start() {
        Scene scene = new Scene(borderPane, 400, 500);

        Main.getPrimaryStage().setTitle("Wo liegt das?");
        Main.getPrimaryStage().setResizable(false);
        Main.getPrimaryStage().setMaximized(false);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }
}
