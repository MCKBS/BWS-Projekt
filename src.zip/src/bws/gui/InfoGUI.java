package bws.gui;

import static bws.gui.StartseiteGUI.logo;
import bws.gui.main.Main;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;

import javafx.stage.Stage;

/**
 *
 * @author Franziska Wuttig
 */
public class InfoGUI {

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * Button um vom Hilfe-Bereich zurueck auf die Startseite zu gelangen.
     */
    private Button zurueckButton;

    /**
     * GridPane, welches den Zurück-Button aufnimmt.
     */
    private GridPane zurueckButtonGrid;

    /**
     * GridPane, für die Kopfzeile.
     */
    private GridPane gridPaneHeaderRow;
    /**
     * Label zur Darstellung des Seitentitels.
     */
    private Label hilfebereichLabel;

    /**
     * Der Text des Hilfebereichs.
     */
    private String hilfebereichText;

    /**
     * Text Area fuer den Hilfebereich.
     */
    private TextArea infoTextArea;

    /**
     * Konstruktor der Klasse.
     *
     * @author Franziska Wuttig
     */
    public InfoGUI() {
        initLabels();
        initButtons();
        initGridPaneHeaderRow();
        initZurueckButtonGrid();
        initHilfebereichText();
        initInfoTextArea();
        initBorderPane();

        zurueckButtonEvent();
    }

    /**
     * Initialisierung der Labels. Die Darstellung der Labels wird angepasst.
     *
     * @author Franziska Wuttig
     */
    private void initLabels() {
        hilfebereichLabel = new Label("Info");

        hilfebereichLabel.setStyle("-fx-font-size: 20pt;");
        hilfebereichLabel.setPadding(new Insets(5, 5, 15, 5));
    }

    /**
     * Initialisierung der Buttons.
     *
     * @author Franziska Wuttig
     */
    private void initButtons() {
        zurueckButton = new Button("Zurück");
    }

    private void initGridPaneHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);
        gridPaneHeaderRow.setStyle("-fx-font-size: 20pt;");

        gridPaneHeaderRow.setAlignment(Pos.CENTER);
        gridPaneHeaderRow.setHalignment(logo, HPos.CENTER);
        gridPaneHeaderRow.setHalignment(hilfebereichLabel, HPos.CENTER);

        gridPaneHeaderRow.add(logo, 0, 0);
        gridPaneHeaderRow.add(hilfebereichLabel, 0, 1);
    }

    /**
     * Initialisierung des Grids fuer den 'Zurueck'-Button. Die Darstellung des
     * Grid wird angepasst.
     *
     * @author Franziska Wuttig
     */
    private void initZurueckButtonGrid() {
        zurueckButtonGrid = new GridPane();

        zurueckButtonGrid.setPadding(new Insets(10, 10, 10, 15));
        zurueckButtonGrid.setAlignment(Pos.CENTER);
        
        zurueckButtonGrid.add(zurueckButton, 0, 0);
    }

    /**
     * Initialisierung des Hilfetexts.
     *
     * @author Franziska Wuttig
     */
    private void initHilfebereichText() {
        hilfebereichText = new String();
        hilfebereichText = "Herzlich Willkommen im Hilfebereich!"
                + "\n\n"
                + "Um zu Spielen logge dich über den Button 'Login' mit deinen Benutzerdaten ein. "
                + "Wenn du noch kein Benutzerkonto hast, dann klicke auf den Button 'Registrieren'. "
                + "Nach der Registrieung, musst du vorher von einem Admin freigeschaltet werden um über dein Benutzerkonto spielen zu können."
                + "\n\n"
                + "Du hast auch die Möglichkeit über den Button 'Play as guest' als Gast zu spielen. "
                + "Allerdings werden dann deine Punkte nicht gespeichert. "
                + "Den Highscore kannst du über den Button 'Highscores' einsehen."
                + "\n\n"
                + "Zum Spiel"
                + "\n\n"
                + "Nachdem du dich eingeloggt hast, ob als Benutzer oder als Gast, kannst du zwischen einer Deutschland,- Europa- oder Weltkarte auswählen um zu spielen. "
                + "Klicke dazu auf den jeweiligen Button. "
                + "Anschließend beginnt auch schon die Spielrunde!"
                + "\n\n"
                + "Du kriegst die gewählte Karte angezeigt und eine Frage dazu gestellt. "
                + "Um die Frage zu beantworten, klicke auf den Punkt auf der Karte von dem du denkst, dass dieser die richtige Antwort ist. "
                + "Zusätzlich zu deiner eigenen Antwort, wird dir dann noch die richtige Antwort ebenfalls als Punkt auf der Karte und auch als Text angezeigt."
                + "\n\n"
                + "Pro Runde bekommst du zehn Fragen gestellt und hast pro Frage nur zehn Sekunden für die Beantwortung!"
                + "Deine Punkte errechnen sich daraus, wie nah du dem richtigen Punkt gekommen bist und wie schnell du die Frage beantworten konntest."
                + "Schaffst du es nicht die Frage innerhalb der Zeit zu beantworten, gilt die Frage als falsch beantwortet und du erhälst leider keine Punkte für diese Frage."
                + "\n\n"
                + "Hast du alle zehn Fragen beantwortet, kriegst du deine Gesamtpunktzahl angezeigt und kannst die den Highscore ansehen!"
                + "\n\n"
                + "Admin"
                + "\n\n"
                + "Als Admin kannst du dich zusätzlich über den Button 'Login als Admin' mit deinen Benutzerdaten einloggen und gelangst damit zum Adminverwaltungsbereich. "
                + "Dort kannst du zwischen der Nutzerverwaltung und der Fragenverwaltung wählen."
                + "\n\n"
                + "In der Nutzerverwaltung werden dir dir alle Nutzer angezeigt. "
                + "Du kannst außerdem neue Nutzer anlegen, Nutzer löschen, Nutzer freigeben oder sperren und die Rolle eines Nutzers (Admin oder normaler Spieler) ändern."
                + "\n\n"
                + "Im Fragenverwaltungsbereich kannst du neue Fragen erstellen, Fragen bearbeiten und Fragen löschen."
                + "\n\n"
                + "Und nun, wünschen wir dir viel Spaß beim Spielen!";
    }

    /**
     * Initialisierung des TextArea zur Anzeige des Hilfetexts. Die Darstellung
     * des TextArea wird angepasst.
     *
     * @author Franziska Wuttig
     */
    private void initInfoTextArea() {
        infoTextArea = new TextArea();

        infoTextArea.setMaxWidth(500);
        infoTextArea.setMinHeight(350);
        infoTextArea.setEditable(false);
        infoTextArea.setWrapText(true);

        infoTextArea.setText(hilfebereichText);

        infoTextArea.setStyle("-fx-focus-color: -fx-control-inner-background; -fx-faint-focus-color: -fx-control-inner-background;");
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(infoTextArea);
        borderPane.setBottom(zurueckButtonGrid);

        borderPane.setPadding(new Insets(15, 15, 15, 15));
        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Weiterleitung zur Startseite.
     *
     * @author Franziska Wuttig
     */
    private void zurueckButtonEvent() {
        zurueckButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent arg0) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                StartseiteGUI startseite = new StartseiteGUI();
                startseite.start();
            }
        });
    }

    /**
     * Zeigt das Fenster an.
     *
     * @author Franziska Wuttig
     */
    public void start() {
        Scene scene = new Scene(borderPane, 600, 900);

        Main.getPrimaryStage().setTitle("Wo liegt das?");
        Main.getPrimaryStage().setResizable(false);
        Main.getPrimaryStage().setMaximized(false);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }
}
