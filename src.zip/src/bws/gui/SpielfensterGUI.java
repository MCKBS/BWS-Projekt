package bws.gui;

import bws.datenmodell.FrageEntity;
import bws.datenmodell.HighscoreEntity;
import bws.datenmodell.ctls.FrageCtl;
import bws.datenmodell.ctls.HighscoreCtl;

import static bws.gui.StartseiteGUI.logoKlein;

import bws.gui.main.Main;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import javafx.concurrent.Worker;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

import javafx.stage.Stage;
import javafx.stage.Window;

import javafx.util.Duration;

import javax.persistence.RollbackException;

import netscape.javascript.JSObject;

/**
 * @author Mert-Can Kocabas
 */
public class SpielfensterGUI {

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * Button um die Spielrunde zu beenden und zur Startseite zu gelangen.
     */
    private Button buttonAufhoeren;

    /**
     * Button um die nächste Frage zu bekommen.
     */
    private Button buttonWeiter;

    /**
     * GridPane, welches den Inhalt der Kopfzeile beinhaltet.
     */
    private GridPane gridPaneHeaderRow;

    /**
     * Label für die Fragennummer.
     */
    private Label labelFrageNr;
    
    /**
     * Label für die Frage.
     */
    private Label labelFrage;
    
    /**
     * Label für den Countdown.
     */
    private Label labelCountdown;

    /**
     * Der Countdown.
     */
    private Timeline timeline;

    /**
     * Die Sekunden des Countdowns.
     */
    private int seconds;

    /**
     * Die Millisekunden des Countdowns.
     */
    private int millis;

    /**
     * Hier wird die Zeit bei der Beantwortung festgehalten.
     */
    private double time;

    /**
     * Die Anzahl an Fragen die beantwortet wurden.
     */
    private int fragenCounter;

    /**
     * Die Gesamtpunktzahl der Spielrunde.
     */
    private double points;

    /**
     * Die Entfernung zur richtigen Lösung in Kilometer und Meter.
     */
    private double distance;

    /**
     * Beinhaltet alle Fragen einer Liste.
     */
    private List<FrageEntity> listeFragen;

    /**
     * Dient als "Verbindungsstück" zwischen JavaFX und HTML.
     */
    private WebEngine webEngine;

    /**
     * Stellt das HTML-Dokument in JavaFX dar.
     */
    private WebView browser;

    public SpielfensterGUI() {
        initWebView();
        initWebEngine();
        initLabels();
        initButtons();
        initStartValues();
        initGridPaneHeaderRow();
        initBorderPane();

        createBridgeBetweenHMTLFile();

        buttonAufhoerenEvent();
        buttonWeiterEvent();
    }

    /**
     * Initialisierung der WebView.
     *
     * @author Mert-Can Kocabas
     */
    private void initWebView() {
        browser = new WebView();
    }

    /**
     * Initialisierung der WebEngine.
     *
     * @author Mert-Can Kocabas
     */
    private void initWebEngine() {
        webEngine = new WebEngine();
        webEngine = browser.getEngine();
    }

    /**
     * Initialisierung der Labels.
     *
     * @author Mert-Can Kocabas
     */
    private void initLabels() {
        labelFrageNr = new Label("Frage Nr: ");
        labelFrage = new Label("Frage: ");
        labelCountdown = new Label("Sekunden übrig: ");
    }

    /**
     * Initialisierung der Buttons.
     *
     * @author Mert-Can Kocabas
     */
    private void initButtons() {
        buttonAufhoeren = new Button("Aufhören");
        buttonWeiter = new Button("Weiter");
    }

    /**
     * Setzt die Startwerte.
     *
     * @author Mert-Can Kocabas
     */
    private void initStartValues() {
        seconds = 10;
        millis = 0;
        fragenCounter = 0;
        points = 0;
        time = 0;
        distance = 0;
    }

    /**
     * Initialisierung des Kopfzeilen-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);

        gridPaneHeaderRow.setAlignment(Pos.CENTER);

        buttonWeiter.setDisable(true);

        gridPaneHeaderRow.setHgrow(labelFrageNr, Priority.ALWAYS);
        gridPaneHeaderRow.setHgrow(labelFrage, Priority.ALWAYS);
        gridPaneHeaderRow.setHgrow(labelCountdown, Priority.ALWAYS);

        gridPaneHeaderRow.setHalignment(labelFrageNr, HPos.CENTER);
        gridPaneHeaderRow.setHalignment(labelFrage, HPos.CENTER);
        gridPaneHeaderRow.setHalignment(labelCountdown, HPos.CENTER);

        gridPaneHeaderRow.add(logoKlein, 0, 0);
        gridPaneHeaderRow.add(buttonAufhoeren, 1, 0);

        gridPaneHeaderRow.add(labelFrageNr, 2, 0);
        gridPaneHeaderRow.add(labelFrage, 3, 0);
        gridPaneHeaderRow.add(labelCountdown, 4, 0);

        gridPaneHeaderRow.add(buttonWeiter, 5, 0);
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(browser);

        borderPane.setPadding(new Insets(5, 0, 0, 0));
        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Beendet die Spielrunde und leitet weiter zur Startseite.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonAufhoerenEvent() {
        buttonAufhoeren.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                StartseiteGUI startseite = new StartseiteGUI();
                startseite.start();
            }
        });
    }

    /**
     * Die Spielrunde wird fortgeführt, außer es wurden schon 10 Fragen
     * beantwortet, dann wird der Benutzer zum Highscore weitergleitet. Ist der
     * Benutzer angemeldet, werden seine Punkte in der Liste gespeichert.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonWeiterEvent() {
        buttonWeiter.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (fragenCounter < 10) {
                    buttonWeiter.setDisable(true);

                    webEngine.executeScript("deleteMarker()");
                    frageStellen();
                    countdown();
                } else {
                    try {
                        if (StartseiteGUI.benutzer != null) {
                            HighscoreCtl highscoreCTL = new HighscoreCtl();
                            HighscoreEntity hs = new HighscoreEntity();

                            hs.setSpieler(StartseiteGUI.benutzer);
                            hs.setPunkte((int) points);

                            highscoreCTL.create(hs);
                        }
                    } catch (RollbackException ex) {
                        System.out.println("Fehler highscore.");
                    }
                    Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                    stage.close();

                    HighscoreGUI highscore = new HighscoreGUI();
                    highscore.start();

                    showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Glückwunsch!", "Du hast " + (int) points + " Punkte erzielt!");
                }
            }
        });
    }

    /**
     * Füllt die Liste mit den Fragen zu der ausgewählten Frage.
     *
     * @author Mert-Can Kocabas
     * @param karte Die Karte auf der der Benutzer spielen möchte.
     * @return Boolean der angibt ob genug Fragen zu der ausgewählten Karte
     * vorhanden sind.
     */
    protected Boolean fillFragenList(String karte) {
        Boolean genugFragen = false;

        FrageCtl frageCTL = new FrageCtl();
        listeFragen = frageCTL.find(karte);
        if (listeFragen.size() >= 10) {
            genugFragen = true;
        }
        return genugFragen;
    }

    /**
     * Fängt an den Countdown runterzuzählen.
     *
     * @author Mert-Can Kocabas
     */
    private void countdown() {
        seconds = 10;
        millis = 0;

        timeline = new Timeline(new KeyFrame(Duration.millis(100), event -> {
            if (millis == 0) {
                seconds--;
                millis = 90;
            }
            millis -= 10;

            if (seconds == 0 && millis == 0) {
                labelCountdown.setText(seconds + "." + millis);
                calcPointsAndContinue();
            }
            labelCountdown.setText(seconds + "." + millis);
        }));
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }

    /**
     * Stellt eine zufällige Frage aus der Datenbank. Auf die Karte wird die
     * Antwort markiert, aber dem Benutzer noch nicht angezeigt. Dies geschieht
     * mit der JavaScript-Methode der jeweiligen HTML-Datei.
     *
     * @author Mert-Can Kocabas
     */
    private void frageStellen() {
        fragenCounter++;

        int randomInt = ThreadLocalRandom.current().nextInt(0, listeFragen.size());
        FrageEntity frage = listeFragen.get(randomInt);
        listeFragen.remove(frage);

        labelFrage.setText(frage.getFrage());
        labelFrageNr.setText(fragenCounter + "");

        webEngine.executeScript("placeMarkerOnMap("
                + frage.getLatLng() + ","
                + "'" + frage.getAntwort() + "')");
    }

    /**
     * Beginnt die Spielrunde.
     *
     * @author Mert-Can Kocabas
     */
    private void playRound() {
        webEngine.getLoadWorker().stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue ov, Worker.State oldState, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    frageStellen();
                    countdown();
                }
            }
        });
    }

    /**
     * Ermöglicht Java-Methoden aus dieser Klasse in JavaScript auszuführen.
     *
     * @author Mert-Can Kocabas
     */
    private void createBridgeBetweenHMTLFile() {
        JSObject window = (JSObject) webEngine.executeScript("window");
        window.setMember("spielfenster", this);
    }

    /**
     * Berechnet die Punkte.
     *
     * @author Mert-Can Kocabas
     */
    public void calcPointsAndContinue() {
        double tempPoints = 0;

        timeline.stop();
        buttonWeiter.setDisable(false);

        distance = (double) webEngine.executeScript("calc()");
        time = Double.parseDouble(labelCountdown.getText());

        if (time == 0.0 || distance < 0) {
            webEngine.executeScript("showCorrectAnswerMarker()");
            tempPoints += 0;
        } else if (time >= 7.5) {
            tempPoints = (3 / distance) * 1000;
        } else if (time >= 3.0) {
            tempPoints = (2 / distance) * 1000;
        } else if (time > 0.0) {
            tempPoints = (1 / distance) * 1000;
        }
        points += tempPoints;
    }

    /**
     * Alert wird dargestellt. Dabei wird dem Alert verschiedene Eigenschaften
     * festgelegt.
     *
     * @author Franziska Wuttig
     * @param alertType Gibt den Typ des Alerts an.
     * @param owner Gibt den 'Besitzer'/Zugehoerigkeit des Alerts an.
     * @param title Gibt den Titel des Alerts an.
     * @param message Gibt die Nachricht an, die angezeigt werden soll.
     */
    private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);

        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    /**
     * Zeigt das Fenster an und startet die Spielrunde.
     *
     * @author Mert-Can Kocabas
     */
    public void start() {
        StackPane root = new StackPane();

        root.getChildren().add(borderPane);

        Scene scene = new Scene(root);

        Main.getPrimaryStage().setTitle("Wo liegt das?");
        Main.getPrimaryStage().setResizable(false);
        Main.getPrimaryStage().setMaximized(true);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();

        playRound();
    }

    /**
     * Gibt die WebEngine zurück.
     *
     * @author Mert-Can Kocabas
     * @return Die WebEngine
     */
    public WebEngine getWebEngine() {
        return webEngine;
    }
}
