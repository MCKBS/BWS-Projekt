package bws.gui;

import bws.gui.main.Main;

import bws.datenmodell.HighscoreEntity;
import bws.datenmodell.ctls.HighscoreCtl;

import static bws.gui.StartseiteGUI.logo;

import java.util.List;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;

import javafx.stage.Stage;

import javafx.util.Callback;

/**
 * @author Mert-Can Kocabas
 */
public class HighscoreGUI {

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * Button, um zurück zur Startseite zu gelangen.
     */
    private Button buttonZurueck;

    /**
     * GridPane, welches den Inhalt der Kopfzeile beinhaltet.
     */
    private GridPane gridPaneHeaderRow;

    /**
     * GridPane, welches den Inhalt der Fußleiste beinhaltet.
     */
    private GridPane gridPaneFooterRow;

    /**
     * Label zur Darstellung des Seitentitels.
     */
    private Label labelTitel;

    /**
     * Enthält alle Highscores aus der Datenbank.
     */
    private ObservableList<HighscoreEntity> observableListHighscore;

    /**
     * TableView für die Darstellung der Highscoretabelle.
     */
    private TableView<HighscoreEntity> tableViewHighscore;

    /**
     * Konstruktor der Klasse
     *
     * @author Mert-Can Kocabas
     */
    public HighscoreGUI() {
        initLabels();
        initButtons();
        initGridPaneHeaderRow();
        initTableView();
        initGridPaneFooterRow();
        initBorderPane();

        buttonZurueckEvent();
    }

    /**
     * Initialisierung der Labels.
     *
     * @author Mert-Can Kocabas
     */
    private void initLabels() {
        labelTitel = new Label("Punktestand");
    }

    /**
     * Initialisierung der Buttons.
     *
     * @author Mert-Can Kocabas
     */
    private void initButtons() {
        buttonZurueck = new Button("Zurück");
    }

    /**
     * Initialisierung des Kopfzeilen-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);

        gridPaneHeaderRow.setStyle("-fx-font-size: 20pt;");

        gridPaneHeaderRow.setHgrow(labelTitel, Priority.ALWAYS);
        gridPaneHeaderRow.setHalignment(labelTitel, HPos.CENTER);

        gridPaneHeaderRow.setAlignment(Pos.CENTER);

        gridPaneHeaderRow.add(logo, 0, 0);
        gridPaneHeaderRow.add(labelTitel, 0, 1);
    }

    /**
     * Initialisierung des TableView. Es werden die nötigen Spalten erstellt und
     * aus der Datenbank befüllt.
     * 
     * @author Mert-Can Kocabas
     */
    private void initTableView() {
        tableViewHighscore = new TableView<HighscoreEntity>();
        tableViewHighscore.setPadding(new Insets(10, 10, 10, 15));

        TableColumn<HighscoreEntity, String> player = new TableColumn<HighscoreEntity, String>("Spieler");
        TableColumn<HighscoreEntity, Integer> punkte = new TableColumn<HighscoreEntity, Integer>("Punkte");

        player.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<HighscoreEntity, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<HighscoreEntity, String> param) {
                return new SimpleObjectProperty<>(param.getValue().getSpieler().getUsername());
            }
        });

        punkte.setCellValueFactory(new PropertyValueFactory<>("punkte"));

        player.setStyle("-fx-alignment: CENTER;");
        punkte.setStyle("-fx-alignment: CENTER;");

        tableViewHighscore.getColumns().addAll(player, punkte);

        HighscoreCtl highscoreCTL = new HighscoreCtl();
        List<HighscoreEntity> highscoreListe = highscoreCTL.findAll();

        observableListHighscore = FXCollections.observableArrayList();

        for (HighscoreEntity highscoreAusListe : highscoreListe) {
            HighscoreEntity highscore = new HighscoreEntity();

            highscore.setId(highscoreAusListe.getId());
            highscore.setSpieler(highscoreAusListe.getSpieler());
            highscore.setPunkte(highscoreAusListe.getPunkte());

            observableListHighscore.add(highscore);
        }
        tableViewHighscore.setItems(observableListHighscore);

        punkte.setSortType(TableColumn.SortType.DESCENDING);
        tableViewHighscore.getSortOrder().add(punkte);
        tableViewHighscore.sort();

        tableViewHighscore.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    /**
     * Initialisierung des Fußzeilen-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneFooterRow() {
        gridPaneFooterRow = new GridPane();

        gridPaneFooterRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneFooterRow.setHgap(5);
        gridPaneFooterRow.setVgap(5);

        gridPaneFooterRow.setAlignment(Pos.BOTTOM_RIGHT);

        gridPaneFooterRow.add(buttonZurueck, 1, 0);
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setPadding(new Insets(15, 15, 15, 15));

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(tableViewHighscore);
        borderPane.setBottom(gridPaneFooterRow);

        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Weiterleitung zur Startseite.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonZurueckEvent() {
        buttonZurueck.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                StartseiteGUI startseite = new StartseiteGUI();
                startseite.start();
            }
        });
    }

    /**
     * Zeigt das Fenster an.
     *
     * @author Mert-Can Kocabas
     */
    public void start() {
        StackPane root = new StackPane();

        root.getChildren().add(borderPane);

        Scene scene = new Scene(root, 1000, 1000);

        Main.getPrimaryStage().setMaximized(false);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }
}
