package bws.gui;

import static bws.gui.StartseiteGUI.logo;

import bws.gui.main.Main;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;

import javafx.stage.Stage;

/**
 *
 * @author Franziska Wuttig
 */
public class AdminVerwaltungGUI {

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * Button um zur Nutzerverwaltung zu gelangen
     */
    private Button nutzerVerwaltungButton;

    /**
     * Button, um zur Fragenverwaltung zu gelangen.
     */
    private Button fragenVerwaltungButton;

    /**
     * Button, um sich abzumelden.
     */
    private Button abmeldenButton;

    /**
     * GridPane für die Kopfzeile.
     */
    private GridPane gridPaneHeaderRow;

    /**
     * GridPane, welches die Buttons der Adminverwaltung beinhaltet.
     */
    private GridPane gridPaneCenter;

    /**
     * GridPane für die Fußzeile.
     */
    private GridPane gridPaneFooterRow;

    /**
     * Label zur Darstellung des Seitentitels.
     */
    private Label labelTitel;

    /**
     * Konstruktor der Klasse.
     *
     * @author Franziska Wuttig
     */
    public AdminVerwaltungGUI() {
        initLabels();
        initButtons();
        initGridPaneHeaderRow();
        initCenterGrid();
        initBottomGrid();
        initBorderPane();

        nutzerVerwaltungButtonEvent();
        abmeldenButtonEvent();
        fragenVerwaltungButtonEvent();
    }

    /**
     * Initialisierung der Labels.
     *
     * @author Franziska Wuttig
     */
    private void initLabels() {
        labelTitel = new Label("Admin Verwaltungsbereich");
    }

    /**
     * Initialisierung der Buttons
     *
     * @author Franziska Wuttig
     */
    private void initButtons() {
        nutzerVerwaltungButton = new Button("Nutzerverwaltung");
        fragenVerwaltungButton = new Button("Fragenverwaltung");
        abmeldenButton = new Button("Abmelden");

        nutzerVerwaltungButton.setMaxWidth(Double.MAX_VALUE);
        fragenVerwaltungButton.setMaxWidth(Double.MAX_VALUE);
    }

    private void initGridPaneHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);

        gridPaneHeaderRow.setAlignment(Pos.CENTER);

        gridPaneHeaderRow.add(logo, 0, 0);
        gridPaneHeaderRow.add(labelTitel, 0, 1);
    }

    /**
     * Initialisierung des GridPanes für die Buttons der Adminverwaltung.
     *
     * @author Franziska Wuttig
     */
    private void initCenterGrid() {
        gridPaneCenter = new GridPane();

        gridPaneCenter.setPadding(new Insets(10, 10, 10, 15));
        gridPaneCenter.setHgap(5);
        gridPaneCenter.setVgap(5);

        gridPaneCenter.setAlignment(Pos.CENTER);

        gridPaneCenter.add(nutzerVerwaltungButton, 0, 0);
        gridPaneCenter.add(fragenVerwaltungButton, 0, 1);
    }

    /**
     * Initialisierung des GridPane für die Fußleiste.
     *
     * @author Franziska Wuttig
     */
    private void initBottomGrid() {
        gridPaneFooterRow = new GridPane();

        gridPaneFooterRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneFooterRow.setHgap(5);
        gridPaneFooterRow.setVgap(5);

        gridPaneFooterRow.setAlignment(Pos.CENTER);

        gridPaneFooterRow.add(abmeldenButton, 0, 0);
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(gridPaneCenter);
        borderPane.setBottom(gridPaneFooterRow);

        borderPane.setPadding(new Insets(15, 15, 15, 15));
        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Weiterleitung zur Nutzerverwaltung.
     *
     * @author Mert-Can Kocabas
     */
    private void nutzerVerwaltungButtonEvent() {
        nutzerVerwaltungButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                NutzerVerwaltungGUI nutzerVerwaltungGUI = new NutzerVerwaltungGUI();
                nutzerVerwaltungGUI.start();
            }
        });
    }

    /**
     * Weiterleitung zur Fragenverwaltung.
     *
     * @author Mert-Can Kocabas
     */
    private void fragenVerwaltungButtonEvent() {
        fragenVerwaltungButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                FragenVerwaltungGUI fragenVerwaltung = new FragenVerwaltungGUI();
                fragenVerwaltung.start();
            }
        });
    }

    /**
     * Weiterleitung zur Startseite.
     *
     * @author Mert-Can Kocabas
     */
    private void abmeldenButtonEvent() {
        abmeldenButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                StartseiteGUI startseite = new StartseiteGUI();
                startseite.start();
            }
        });
    }

    /**
     * Zeigt das Fenster an.
     *
     * @author Franziska Wuttig
     */
    public void start() {
        Scene scene = new Scene(borderPane, 450, 400);

        Main.getPrimaryStage().setMaximized(false);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }
}
