package bws.gui;

import bws.datenmodell.NutzerEntity;
import bws.datenmodell.ctls.NutzerCtl;

import bws.gui.main.Main;

import bws.logik.UserRegisterLogik;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Arrays;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import javafx.stage.Stage;
import javafx.stage.Window;

import javax.persistence.NoResultException;

/**
 * @author Franziska Wuttig
 */
public class StartseiteGUI {

    /**
     * Boolean zur ueberpruefung ob der Nutzer sich als Admin anmelden moechte.
     */
    private Boolean adminLogin = false;

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * Button zum einloggen des Benutzers.
     */
    private Button loginButton;

    /**
     * Button um den Benutzer zur Benutzerregistrierungs-Seite weiterzuleiten.
     */
    private Button registrierenButton;

    /**
     * Button um als Gast zu spielen.
     */
    private Button playAsGuestButton;

    /**
     * Button um sich die Highscore-Liste anzeigen zu lassen.
     */
    private Button highscoreButton;

    /**
     * Button um sich als Admin einzuloggen und zur Adminverwaltung zu gelangen.
     */
    private Button adminVerwaltungButton;

    /**
     * Button, welcher zum Hilfebereich weiterleitet.
     */
    private Button infoButton;

    /**
     * GridPane, welches den Inhalt der Kopfzeile beinhaltet.
     */
    private GridPane gridPaneHeaderRow;

    /**
     * GridPane, welches die Eingabemaske beinhaltet.
     */
    private GridPane gridPaneEingabemaske;

    /**
     * GridPane fuer die Buttons, die nicht in der Fußleiste seien sollen.
     */
    private GridPane gridPaneCenterButtons;

    /**
     * GridPane, welches den Inhalt der Fußleiste beinhaltet.
     */
    private GridPane gridPaneFooterRow;

    /**
     * Das Logo der Anwendung.
     */
    public static volatile ImageView logo;

    /**
     * Das Logo der Anwendung, nur kleiner.
     */
    public static volatile ImageView logoKlein;

    /**
     * Label zur Darstellung des Seitentitels.
     */
    private Label labelTitel;

    /**
     * Label fuer das Benutzername-Eingabefeld.
     */
    private Label usernameLabel;

    /**
     * Label fuer das Passwort-Eingabefeld.
     */
    private Label passwordLabel;

    /**
     * 'Button'-Label zur Weiterleitung zur Passwort-aendern-Seite.
     */
    private Label labelChangePassword;

    /**
     * Hier wird der eingeloggte Benutzer festgehalten.
     */
    public static volatile NutzerEntity benutzer;

    /**
     * Passwort-Eingabefeld.
     */
    private PasswordField passwordPasswordField;

    /**
     * Benutzername-Eingabefeld.
     */
    private TextField usernameTextField;

    /**
     * Nimmt das Eingabemasken-Grid und das Button-Grid auf.
     */
    private VBox centerVBox;

    /**
     * Konstruktor der Klasse.
     *
     * @author Franziska Wuttig
     */
    public StartseiteGUI() {
        initLogo();
        initLabels();
        initButtons();
        initEingabemaskeFields();
        initGridHeaderRow();
        initGridEingabemaske();
        initGridCenterButtons();
        initCenterVBox();
        initFooterGrid();
        initBorderPane();

        loginButtonEvent();
        registrierenButtonEvent();
        playAsGuestButtonEvent();
        highscoreButtonEvent();
        adminVerwaltungButtonEvent();
        infoButtonEvent();
        changePasswordEvent();
    }

    /**
     * Initialisierung des Logos.
     *
     * @author Mert-Can Kocabas
     */
    private void initLogo() {
        logo = new ImageView();
        logo.setImage(new Image(this.getClass().getResource("/bws/resources/img/logo.jpg").toExternalForm()));
        logo.setFitWidth(150);
        logo.setPreserveRatio(true);
        logo.setSmooth(true);
        logo.setCache(true);

        logoKlein = new ImageView();
        logoKlein.setImage(new Image(this.getClass().getResource("/bws/resources/img/logo.jpg").toExternalForm()));
        logoKlein.setFitWidth(50);
        logoKlein.setPreserveRatio(true);
        logoKlein.setSmooth(true);
        logoKlein.setCache(true);
    }

    /**
     * Initialisierung der Labels. Die Darstellung der Labels wird angepasst.
     *
     * @author Franziska Wuttig
     */
    private void initLabels() {
        labelTitel = new Label("Wo liegt das?!");
        usernameLabel = new Label("Benutzername");
        passwordLabel = new Label("Passwort");
        labelChangePassword = new Label("Passwort ändern");

        labelChangePassword.setStyle("-fx-font-size: 10pt;");
    }

    /**
     * Initialisierung der Buttons.
     *
     * @author Franziska Wuttig
     */
    private void initButtons() {
        loginButton = new Button("Einloggen");
        registrierenButton = new Button("Registrieren");
        playAsGuestButton = new Button("Als Gast spielen");
        highscoreButton = new Button("Punktestand");
        infoButton = new Button("Info");
        adminVerwaltungButton = new Button("Als Admin einloggen");
    }

    /**
     * Initialisierung der Eingabefelder.
     *
     * @author Franziska Wuttig
     */
    private void initEingabemaskeFields() {
        usernameTextField = new TextField();
        passwordPasswordField = new PasswordField();
    }

    /**
     * Initialisierung des Kopfzeilen-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franiska Wuttig
     */
    private void initGridHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);
        gridPaneHeaderRow.setStyle("-fx-font-size: 20pt;");

        gridPaneHeaderRow.setAlignment(Pos.CENTER);
        gridPaneHeaderRow.setHalignment(logo, HPos.CENTER);

        gridPaneHeaderRow.add(logo, 0, 0);
        gridPaneHeaderRow.add(labelTitel, 0, 1);
    }

    /**
     * Initialisierung des Eingabemaske-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initGridEingabemaske() {
        gridPaneEingabemaske = new GridPane();

        gridPaneEingabemaske.setPadding(new Insets(10, 10, 10, 15));
        gridPaneEingabemaske.setHgap(5);
        gridPaneEingabemaske.setVgap(5);

        gridPaneEingabemaske.setAlignment(Pos.CENTER);

        gridPaneEingabemaske.add(usernameLabel, 0, 0);
        gridPaneEingabemaske.add(usernameTextField, 0, 1);

        gridPaneEingabemaske.add(passwordLabel, 0, 2);
        gridPaneEingabemaske.add(passwordPasswordField, 0, 3);
    }

    /**
     * Initialisierung des Center-Buttons-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initGridCenterButtons() {
        gridPaneCenterButtons = new GridPane();

        gridPaneCenterButtons.setPadding(new Insets(10, 10, 10, 15));
        gridPaneCenterButtons.setHgap(5);
        gridPaneCenterButtons.setVgap(5);

        gridPaneCenterButtons.setAlignment(Pos.CENTER);

        playAsGuestButton.setMaxWidth(Double.MAX_VALUE);
        highscoreButton.setMaxWidth(Double.MAX_VALUE);

        gridPaneCenterButtons.add(loginButton, 0, 0);
        gridPaneCenterButtons.add(registrierenButton, 1, 0);
        gridPaneCenterButtons.add(playAsGuestButton, 0, 1, 2, 1);
        gridPaneCenterButtons.add(highscoreButton, 0, 2, 2, 1);
    }

    /**
     * Initialisierung der VBox, die die EingabeMaske und die Buttons aufnimmt.
     * Der VBox wird das GridPane der Eingabemaske und das GridPane der Buttons
     * hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initCenterVBox() {
        centerVBox = new VBox();

        centerVBox.getChildren().addAll(gridPaneEingabemaske, gridPaneCenterButtons);
    }

    /**
     * Initialisierung des Fußleisten-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initFooterGrid() {
        gridPaneFooterRow = new GridPane();

        gridPaneFooterRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneFooterRow.setHgap(5);
        gridPaneFooterRow.setVgap(5);

        gridPaneFooterRow.setAlignment(Pos.CENTER);

        gridPaneFooterRow.add(infoButton, 0, 0);
        gridPaneFooterRow.add(adminVerwaltungButton, 1, 0);
        gridPaneFooterRow.add(labelChangePassword, 0, 1, 2, 1);

        gridPaneFooterRow.setHalignment(labelChangePassword, HPos.CENTER);
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(centerVBox);
        borderPane.setBottom(gridPaneFooterRow);

        borderPane.setPadding(new Insets(15, 15, 15, 15));
        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Weiterleitung zur Levelauswahl, um als registrierter Nutzer zu spielen.
     * Der Benutzer wird weitergeleitet, wenn seine Anmeldedaten korrekt sind.
     * Beim Fensterwechsel wird der Nutzer weitergegeben, der sich angemeldet
     * hat.
     *
     * @author Mert-Can Kocabas
     */
    private void loginButtonEvent() {
        loginButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (anmeldeDatenKorrekt()) {
                    Logger.getLogger(StartseiteGUI.class.getName()).log(Level.INFO, "Benutzer hat sich angemeldet");

                    Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                    stage.close();

                    LevelAuswahlGUI levelAuswahl = new LevelAuswahlGUI();
                    levelAuswahl.start();

                    showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Login erfolgreich", "Willkommen " + usernameTextField.getText()
                            + ", Viel Spaß beim Spielen");
                }
            }
        });
    }

    /**
     * Weiterleitung zur Nutzerregistrierung.
     *
     * @author Mert-Can Kocabas
     */
    private void registrierenButtonEvent() {
        registrierenButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                UserRegisterGUI userRegister = new UserRegisterGUI();
                userRegister.start();
            }
        });
    }

    /**
     * Weiterleitung zur Levelauswahl, um als Gast zu spielen.
     *
     * @author Mert-Can Kocabas
     */
    private void playAsGuestButtonEvent() {
        playAsGuestButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                LevelAuswahlGUI levelAuswahl = new LevelAuswahlGUI();
                levelAuswahl.start();
            }
        });
    }

    /**
     * Weiterleitung zur Highscore-Tabelle.
     *
     * @author Mert-Can Kocabas
     */
    private void highscoreButtonEvent() {
        highscoreButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                HighscoreGUI highscore = new HighscoreGUI();
                highscore.start();
            }
        });
    }

    /**
     * Weiterleitung zur Adminverwaltung. Der Benutzer wird weitergeleitet, wenn
     * seine Anmeldedaten korrekt sind.
     *
     * @author Mert-Can Kocabas
     */
    private void adminVerwaltungButtonEvent() {
        adminVerwaltungButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                adminLogin = true;

                if (anmeldeDatenKorrekt()) {
                    System.out.println("STARTSEITE: " + benutzer.getUsername());
                    Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                    stage.close();

                    AdminVerwaltungGUI adminverwaltungGUI = new AdminVerwaltungGUI();
                    adminverwaltungGUI.start();

                    showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Login Erfolgreich", "Willkomen " + benutzer.getUsername());
                }
            }
        });
    }

    /**
     * Weiterleitung zum Info-Fenster.
     *
     * @author Franziska Wuttig
     */
    private void infoButtonEvent() {
        infoButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                InfoGUI infoGUI = new InfoGUI();
                infoGUI.start();
            }
        });
    }

    /**
     * Weiterleitung zum 'Passwort-aendern'-Fenster.
     *
     * @author Franziska Wuttig
     */
    private void changePasswordEvent() {
        labelChangePassword.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent arg0) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                PasswordAendernGUI pwAendernGUI = new PasswordAendernGUI();
                pwAendernGUI.start();
            }
        });
    }

    /**
     * Prüft, ob die Anmeldedaten korrekt waren.
     *
     * @author Franziska Wuttig
     * @return Die Boolean-Variable, die angibt, ob die Anmeldedaten korrekt
     * waren.
     */
    private boolean anmeldeDatenKorrekt() {
        boolean loginKorrekt = false;

        if ((usernameTextField.getText().isEmpty()) || (passwordPasswordField.getText().isEmpty())) {
            showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Benutzername oder Passwort ist ungültig");
        } else {
            if (anmeldeDatenUeberpruefung()) {
                loginKorrekt = true;
            } else {
                loginKorrekt = false;
            }
        }
        return loginKorrekt;
    }

    /**
     * Prüft, ob die Anmeldedaten korrekt sind.
     *
     * @author Franziska Wuttig
     * @return Die Boolean-Variable, die angibt, ob die eingegebenen
     * Anmeldedaten korrekt sind.
     */
    private boolean anmeldeDatenUeberpruefung() {
        boolean login = false;
        try {
            NutzerCtl nCtl = new NutzerCtl();
            NutzerEntity nE = new NutzerEntity();

            nE = nCtl.find(usernameTextField.getText());

            byte[] passwortVerschlusselt = UserRegisterLogik.verschlusseln(passwordPasswordField.getText());

            if (nE.isGesperrt()) {
                showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Nutzer ist gesperrt!", "Du musst erst von einem Admin freigeschaltet werden");
            } else {
                if (adminLogin) {
                    if (nE.isRolle()) {
                        if (Arrays.equals(passwortVerschlusselt, nE.getPassword())) {
                            login = true;
                        } else {
                            login = false;

                            showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Login Fehlgeschlagen", "Benutzername und Passwort prüfen");
                        }
                    } else {
                        showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Kein Admin", "Du bist kein Admin!");
                    }
                } else {
                    if (Arrays.equals(passwortVerschlusselt, nE.getPassword())) {
                        login = true;
                    } else {
                        login = false;

                        showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Login Fehlgeschlagen", "Benutzername und Passwort prüfen");
                    }
                }
            }
            benutzer = nE;
        } catch (NullPointerException | NoResultException ex) {
            showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Login Fehlgeschlagen", "Benutzername und Passwort prüfen");
        }
        return login;
    }

    /**
     * Alert wird dargestellt. Dabei wird dem Alert verschiedene Eigenschaften
     * festgelegt.
     *
     * @author Franziska Wuttig
     * @param alertType Gibt den Typ des Alerts an.
     * @param owner Gibt den 'Besitzer'/Zugehoerigkeit des Alerts an.
     * @param title Gibt den Titel des Alerts an.
     * @param message Gibt die Nachricht an, die angezeigt werden soll.
     */
    public void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);

        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    /**
     * Zeigt das Fenster an.
     *
     * @author Mert-Can Kocabas
     */
    public void start() {
        Scene scene = new Scene(borderPane, 500, 650);

        Main.getPrimaryStage().setTitle("Wo liegt das?");
        Main.getPrimaryStage().setResizable(false);
        Main.getPrimaryStage().setMaximized(false);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }
}
