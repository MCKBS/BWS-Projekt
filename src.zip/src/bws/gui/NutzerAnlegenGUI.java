package bws.gui;

import bws.datenmodell.NutzerEntity;
import bws.datenmodell.ctls.NutzerCtl;
import static bws.gui.StartseiteGUI.logo;

import bws.gui.main.Main;

import bws.logik.UserRegisterLogik;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import javafx.stage.Stage;
import javafx.stage.Window;

import javax.persistence.RollbackException;

/**
 * @author Franziska Wuttig
 */
public class NutzerAnlegenGUI {

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * Button um Benutzer anzulegen
     */
    private Button anlegenButton;

    /**
     * Button um Vorgang abzubrechen.
     */
    private Button abbrechenButton;

    /**
     * GridPane, welches den Inhalt der Kopfzeile beinhaltet.
     */
    private GridPane gridPaneHeaderRow;

    /**
     * GridPane, welches die Eingabemaske beinhaltet.
     */
    private GridPane gridPaneEingabemaske;

    /**
     * GridPane fuer die Buttons, die nicht in der Fußleiste seien sollen.
     */
    private GridPane gridPaneCenterButtons;

    /**
     * GridPane fuer die Buttons.
     */
    private GridPane footerGrid;

    /**
     * Label zur Darstellung des Seitentitels.
     */
    private Label titelLabel;

    /**
     * Label fuer das Benutzername-Eingabefeld.
     */
    private Label usernameLabel;

    /**
     * Label fuer das Passwort-Eingabefeld.
     */
    private Label passwordLabel;

    /**
     * Label fuer das Passwort-Wiederholen-Eingabefeld.
     */
    private Label repeatPasswordLabel;

    /**
     * Benutzername-Eingabefeld.
     */
    private TextField usernameTextField;

    /**
     * Passwort-Eingabefeld.
     */
    private PasswordField passwordPasswordField;

    /**
     * Passwort-Wiederholung-Eingabefeld.
     */
    private PasswordField repeatPasswordPasswordField;

    /**
     * Nimmt das Eingabemasken-Grid und das Button-Grid auf.
     */
    private VBox centerVBox;

    /**
     * Konstruktor der Klasse.
     *
     * @author Franziska Wuttig
     */
    public NutzerAnlegenGUI() {
        initLabels();
        initButtons();
        initGridPaneHeaderRow();
        initEingabemaskeFields();
        initGridEingabemaske();
        initGridCenterButtons();
        initCenterVBox();
        initFooterGrid();
        initBorderPane();

        anlegenBtnEvent();
        abbrechenButtonEvent();
    }

    /**
     * Initialisierung der Labels. Die Darstellung der Labels wird angepasst.
     *
     * @author Franziska Wuttig
     */
    private void initLabels() {
        titelLabel = new Label("Benutzer Anlegen");
        usernameLabel = new Label("Benutzername");
        passwordLabel = new Label("Passwort");
        repeatPasswordLabel = new Label("Passwort wiederholen");

        titelLabel.setStyle("-fx-font-size: 20pt;");
        titelLabel.setPadding(new Insets(25, 0, 25, 0));
    }

    /**
     * Initialisierung der Buttons
     *
     * @author Franziska Wuttig
     */
    private void initButtons() {
        anlegenButton = new Button("Anlegen");
        abbrechenButton = new Button("Abbrechen");
    }

    /**
     * Initialisierung des Kopfzeilen-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franiska Wuttig
     */
    private void initGridPaneHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);
        gridPaneHeaderRow.setStyle("-fx-font-size: 20pt;");

        gridPaneHeaderRow.setAlignment(Pos.CENTER);
        gridPaneHeaderRow.setHalignment(logo, HPos.CENTER);

        gridPaneHeaderRow.add(logo, 0, 0);
        gridPaneHeaderRow.add(titelLabel, 0, 1);
    }

    /**
     * Initialisierung der Eingabemaskefelder.
     *
     * @author Franziska Wuttig
     */
    private void initEingabemaskeFields() {
        usernameTextField = new TextField();
        passwordPasswordField = new PasswordField();
        repeatPasswordPasswordField = new PasswordField();

        Tooltip tooltipPasswort = new Tooltip("Das Passwort muss mindestens 8 Zeichen lang sein.\n"
                + "Das Passwort muss mindestens einen Großbuchstaben enthalten.\n"
                + "Das Passwort muss mindestens einen Kleinbuchstaben enthalten.\n"
                + "Das Passwort muss mindestens eine Ziffer enthalten.\n"
                + "Das Passwort kann, muss aber nicht, Sonderzeichen enthalten.");

        passwordPasswordField.setTooltip(tooltipPasswort);
    }

    /**
     * Initialisierung des Eingabemaske-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initGridEingabemaske() {
        gridPaneEingabemaske = new GridPane();

        gridPaneEingabemaske.setPadding(new Insets(10, 10, 10, 15));
        gridPaneEingabemaske.setHgap(5);
        gridPaneEingabemaske.setVgap(5);

        gridPaneEingabemaske.setAlignment(Pos.CENTER);

        gridPaneEingabemaske.add(usernameLabel, 0, 0);
        gridPaneEingabemaske.add(usernameTextField, 0, 1);

        gridPaneEingabemaske.add(passwordLabel, 0, 2);
        gridPaneEingabemaske.add(passwordPasswordField, 0, 3);

        gridPaneEingabemaske.add(repeatPasswordLabel, 0, 4);
        gridPaneEingabemaske.add(repeatPasswordPasswordField, 0, 5);
    }

    /**
     * Initialisierung des Center-Buttons-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initGridCenterButtons() {
        gridPaneCenterButtons = new GridPane();
        gridPaneCenterButtons.setPadding(new Insets(10, 10, 10, 15));
        gridPaneCenterButtons.setHgap(10);
        gridPaneCenterButtons.setVgap(10);

        gridPaneCenterButtons.setAlignment(Pos.CENTER);

        anlegenButton.setMaxWidth(Double.MAX_VALUE);

        gridPaneCenterButtons.add(anlegenButton, 0, 0);
    }

    /**
     * Initialisierung der VBox, welche die Eingabemaske und die Buttons
     * aufnimmt. Der VBox wird das GridPane der Eingabemaske und das GridPane
     * der Buttons hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initCenterVBox() {
        centerVBox = new VBox();
        centerVBox.getChildren().addAll(gridPaneEingabemaske, gridPaneCenterButtons);
    }

    /**
     * Initialisierung des Fußleisten-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initFooterGrid() {
        footerGrid = new GridPane();

        footerGrid.setPadding(new Insets(10, 10, 10, 15));
        footerGrid.setHgap(5);
        footerGrid.setVgap(5);

        footerGrid.setAlignment(Pos.CENTER);

        footerGrid.add(abbrechenButton, 0, 0);
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(centerVBox);
        borderPane.setBottom(footerGrid);

        borderPane.setPadding(new Insets(15, 15, 15, 15));
        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Legt einen neuen Benutzer an. Prueft ob in den Eingabefeldern korrekte
     * Werte sind. Leitet nach erfolgreicher Erstellung weiter zur
     * Benutzerverwaltung.
     *
     * @author Franziska Wuttig
     */
    private void anlegenBtnEvent() {
        anlegenButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (usernameTextField.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Benutzername ist ungültig!");
                    clearFields();
                    return;
                }
                if (passwordPasswordField.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Passwort ist ungültig!");
                    clearFields();
                    return;
                }
                if (repeatPasswordPasswordField.getText().isEmpty() || !repeatPasswordPasswordField.getText().equals(passwordPasswordField.getText())) {
                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Passwörter stimmen nicht überein!");
                    clearFields();
                    return;
                }

                try {
                    NutzerCtl nctl = new NutzerCtl();
                    NutzerEntity nutzer = new NutzerEntity();

                    usernameTextField.setText(usernameTextField.getText().replace(" ", ""));
                    nutzer.setUsername(usernameTextField.getText());

                    if (passwordPasswordField.getText().matches("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$")) {
                        byte[] passwortVerschluesselt = UserRegisterLogik.verschlusseln(passwordPasswordField.getText());

                        nutzer.setPassword(passwortVerschluesselt);
                        nutzer.setRolle(false);

                        nctl.create(nutzer);

                        Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                        stage.close();

                        NutzerVerwaltungGUI nutzerverwaltungGUI = new NutzerVerwaltungGUI();
                        nutzerverwaltungGUI.start();

                        showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Registrierung erfolgreich!", "Willkommen " + usernameTextField.getText() + "!");
                    } else {
                        showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Passwort überprüfen!", "Bitte überprüfe ob dein Passwort alle Kriterien erfüllt!");
                    }

                } catch (RollbackException ex) {
                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Registrierung fehlgeschlagen!", "Anderen Benutzernamen wählen!");
                }
            }
        });
    }

    /**
     * Weiterleitung zur Nutzerverwaltung.
     *
     * @author Mert-Can Kocabas
     */
    private void abbrechenButtonEvent() {
        abbrechenButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                NutzerVerwaltungGUI nutzerVerwaltung = new NutzerVerwaltungGUI();
                nutzerVerwaltung.start();
            }
        });
    }

    /**
     * Alert wird dargestellt. Dabei wird dem Alert verschiedene Eigenschaften
     * festgelegt.
     *
     * @author Franziska Wuttig
     * @param alertType Gibt den Typ des Alerts an.
     * @param owner Gibt den 'Besitzer'/Zugehoerigkeit des Alerts an.
     * @param title Gibt den Titel des Alerts an.
     * @param message Gibt die Nachricht an, die angezeigt werden soll.
     */
    private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    /**
     * Methode zum Leeren der Textfelder für Benutzername, Passwort und
     * Passwortwiederholung.
     *
     * @author Franziska Wuttig
     */
    private void clearFields() {
        usernameTextField.clear();
        passwordPasswordField.clear();
        repeatPasswordPasswordField.clear();
    }

    /**
     * Zeigt das Fenster an.
     *
     * @author Mert-Can Kocabas
     */
    public void start() {
        Scene scene = new Scene(borderPane, 500, 650);

        Main.getPrimaryStage().setTitle("Wo liegt das?!");
        Main.getPrimaryStage().setResizable(false);
        Main.getPrimaryStage().setMaximized(false);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }
}
