package bws.gui;

import bws.gui.main.Main;

import bws.datenmodell.NutzerEntity;
import bws.datenmodell.ctls.NutzerCtl;
import static bws.gui.StartseiteGUI.logo;

import bws.logik.TableCellAktivitaet;
import bws.logik.TableCellRolle;

import java.util.List;
import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

import javafx.stage.Stage;
import javafx.stage.Window;

import javafx.util.Callback;

/**
 * @author Mert-Can Kocabas
 */
public class NutzerVerwaltungGUI {

    /**
     * TableView welches die Liste der Benutzer aus der Datenbank anzeigt.
     */
    private TableView<NutzerEntity> tableViewNutzer;

    /**
     * Liste welche die Benutzer aus der Datenbank beinhaltet.
     */
    private ObservableList<NutzerEntity> observableList;

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * GridPane, welches den Inhalt der Kopfzeile beinhaltet.
     */
    private GridPane gridPaneHeaderRow;

    /**
     * GridPane welches den Inhalt der Fußzeile beinhaltet.
     */
    private GridPane gridPaneFooterRow;

    /**
     * GridPane welches die Liste der Benutzer und alle Buttons die fuer das
     * Erstellen, Loeschen, Aendern der Rolle und Sperren oder Entsperren eines
     * Benutzers noetig sind.
     */
    private GridPane gridPaneNutzer;

    /**
     * Titellabel des Fensters.
     */
    private Label labelTitel;

    /**
     * Untertitellabel des Fensters.
     */
    private Label labelNutzerListe;

    /**
     * Button um zurueck zum Adminverwaltungsbereich zu gelangen.
     */
    private Button buttonZurueck;

    /**
     * Button um einen Benutzer zu loeschen.
     */
    private Button buttonNutzerLoeschen;

    /**
     * Button um die Aktivitaet eines Benutzers zu aendern.
     */
    private Button buttonNutzerSperrenEntsperren;

    /**
     * Button um die Rolle eines Benutzers zu aendern.
     */
    private Button buttonNutzerRolleZuweisen;

    /**
     * Button um neuen Benutzer anzulegen.
     */
    private Button buttonNutzerAnlegen;

    /**
     * Konstruktor der Klasse.
     *
     * @author Franziska Wuttig
     */
    public NutzerVerwaltungGUI() {
        initLabels();
        initButtons();
        initGridPaneHeaderRow();
        initTableView();
        initGridPaneNutzer();
        initGridPaneFooerRow();
        initBorderPane();

        deleteNutzer();

        btnEventNutzerRolleAendern();
        btnEventAktivitaetAendern();
        buttonZurueckEvent();
        buttonNutzerAnlegenEvent();
    }

    private void initLabels() {
        labelTitel = new Label("Nutzerverwaltung");
        labelNutzerListe = new Label("Liste aller Benutzer");
    }

    private void initButtons() {
        buttonZurueck = new Button("Zurück");
        buttonNutzerLoeschen = new Button("Benutzer Löschen");
        buttonNutzerSperrenEntsperren = new Button("Benutzer sperren/entsperren");
        buttonNutzerRolleZuweisen = new Button("Benutzerrolle ändern");
        buttonNutzerAnlegen = new Button("Benutzer anlegen");
    }

    /**
     * Initialisierung des GridPanes welches den Inhalt Kopfzeile beinhaltet.
     * Die jeweiligen Elemente werden hinzugefuegt und die Darstellung
     * angepasst.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);
        gridPaneHeaderRow.setStyle("-fx-font-size: 20pt;");

        gridPaneHeaderRow.setAlignment(Pos.CENTER);
        gridPaneHeaderRow.setHalignment(logo, HPos.CENTER);

        gridPaneHeaderRow.add(logo, 0, 0);
        gridPaneHeaderRow.add(labelTitel, 0, 1);
    }

    /**
     * Initialisierung der Table View und Hinzufuegen der Spalten. Anschließend
     * wird der Inhalt aus der Datenbank hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initTableView() {
        tableViewNutzer = new TableView<>();

        TableColumn<NutzerEntity, String> username = new TableColumn<NutzerEntity, String>("Benutzername");
        username.setCellValueFactory(new PropertyValueFactory<>("username"));

        TableColumn<NutzerEntity, Boolean> rolleSpalte = initRolleColumn();
        TableColumn<NutzerEntity, Boolean> aktivitaetSpalte = initAktivitaetColumn();

        tableViewNutzer.getColumns().addAll(username, rolleSpalte, aktivitaetSpalte);

        NutzerCtl nCtl = new NutzerCtl();
        List<NutzerEntity> nutzerList = nCtl.findAll();

        observableList = FXCollections.observableArrayList();

        for (NutzerEntity nutzerAusListe : nutzerList) {
            NutzerEntity nE = new NutzerEntity();
            nE.setId(nutzerAusListe.getId());
            nE.setUsername(nutzerAusListe.getUsername());
            nE.setPassword(nutzerAusListe.getPassword());
            nE.setRolle(nutzerAusListe.isRolle());
            nE.setGesperrt(nutzerAusListe.isGesperrt());

            observableList.add(nE);
        }
        observableList.remove(StartseiteGUI.benutzer);
        tableViewNutzer.setItems(observableList);

        tableViewNutzer.setPrefSize(600, 500);
        tableViewNutzer.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    /**
     * Initialisierung des GridPanes welches die Liste der Benutzer und alle
     * Buttons die fuer das Erstellen, Loeschen, Aendern der Rolle und Sperren
     * oder Entsperren eines Benutzers noetig sind. Die jeweiligen Elemente
     * werden hinzugefuegt und die Darstellung wird angepasst.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneNutzer() {
        gridPaneNutzer = new GridPane();

        gridPaneNutzer.setPadding(new Insets(10, 10, 10, 15));
        gridPaneNutzer.setHgap(5);
        gridPaneNutzer.setVgap(5);

        gridPaneNutzer.setAlignment(Pos.CENTER);

        gridPaneNutzer.setHgrow(labelNutzerListe, Priority.ALWAYS);
        gridPaneNutzer.setHalignment(labelNutzerListe, HPos.CENTER);

        buttonNutzerLoeschen.setMaxWidth(Double.MAX_VALUE);

        gridPaneNutzer.add(labelNutzerListe, 0, 0, 2, 1);
        gridPaneNutzer.add(tableViewNutzer, 0, 1, 2, 1);
        gridPaneNutzer.add(buttonNutzerLoeschen, 0, 2);
        gridPaneNutzer.add(buttonNutzerSperrenEntsperren, 1, 2);
        gridPaneNutzer.add(buttonNutzerRolleZuweisen, 0, 3);
        gridPaneNutzer.add(buttonNutzerAnlegen, 1, 3);
    }

    /**
     * Initialisierung des GridPanes welches den Inhalt der Fußzeile beinhaltet.
     * Die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneFooerRow() {
        gridPaneFooterRow = new GridPane();

        gridPaneFooterRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneFooterRow.setHgap(5);
        gridPaneFooterRow.setVgap(5);

        gridPaneFooterRow.setAlignment(Pos.BOTTOM_RIGHT);

        gridPaneFooterRow.add(buttonZurueck, 0, 0);
    }

    /**
     * Initialisierung des BorderPanes und Hinzufuegen der Elemente zum
     * BorderPane. Die Darstellung wird angepasst.
     *
     * @author Mert-Can Kocabas
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(gridPaneNutzer);
        borderPane.setBottom(gridPaneFooterRow);

        borderPane.setPadding(new Insets(15, 15, 15, 15));

        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Initialisierung der Spalte Rolle. Anschließend wird der Inhalt der Spalte
     * aktualisiert.
     *
     * @author Franziska Wuttig
     * @return gibt die Rolle eines Nutzers zurueck
     */
    private TableColumn<NutzerEntity, Boolean> initRolleColumn() {
        TableColumn<NutzerEntity, Boolean> rolle = new TableColumn<NutzerEntity, Boolean>("Rolle");
        rolle.setCellValueFactory(new PropertyValueFactory<>("rolle"));
        Callback<TableColumn<NutzerEntity, Boolean>, TableCell<NutzerEntity, Boolean>> callback
                = (TableColumn<NutzerEntity, Boolean> rolleCell) -> new TableCellRolle();
        rolle.setCellFactory(callback);
        return rolle;
    }

    /**
     * Initialisierung der Spalte Aktivitaet. Anschließend wird der Inhalt der
     * Spalte aktualisiert.
     *
     * @author Franziska Wuttig
     * @return gibt die Aktivitaet eines Nutzers zurueck
     */
    private TableColumn<NutzerEntity, Boolean> initAktivitaetColumn() {
        TableColumn<NutzerEntity, Boolean> aktivitaet = new TableColumn<NutzerEntity, Boolean>("Aktivität");
        aktivitaet.setCellValueFactory(new PropertyValueFactory<>("gesperrt"));
        Callback<TableColumn<NutzerEntity, Boolean>, TableCell<NutzerEntity, Boolean>> callback
                = (TableColumn<NutzerEntity, Boolean> aktivitaetCell) -> new TableCellAktivitaet();
        aktivitaet.setCellFactory(callback);
        return aktivitaet;
    }

    /**
     * Entfernt alle Elemente aus dem TableView und fuegt sie neu hinzu, um die
     * Inhalte zu aktualisieren.
     *
     * @author Franziska Wuttig
     */
    private void refreshTableView() {
        tableViewNutzer.getItems().clear();

        NutzerCtl nCtl = new NutzerCtl();
        List<NutzerEntity> nutzerList = nCtl.findAll();
        observableList = FXCollections.observableArrayList();

        for (NutzerEntity nutzerAusListe : nutzerList) {
            NutzerEntity nE = new NutzerEntity();
            nE.setId(nutzerAusListe.getId());
            nE.setUsername(nutzerAusListe.getUsername());
            nE.setPassword(nutzerAusListe.getPassword());
            nE.setRolle(nutzerAusListe.isRolle());
            nE.setGesperrt(nutzerAusListe.isGesperrt());

            observableList.add(nE);
        }
        observableList.remove(StartseiteGUI.benutzer);
        tableViewNutzer.setItems(observableList);
    }

    /**
     * Loescht einen ausgewaehlten Benutzer aus dem TableView und der Datenbank.
     *
     * @author Mert-Can Kocabas
     */
    private void deleteNutzer() {
        buttonNutzerLoeschen.setOnAction(e -> {
            try {
                NutzerEntity nutzer = tableViewNutzer.getSelectionModel().getSelectedItem();
                if (nutzer != null) {

                    ButtonType buttonTypeJa = new ButtonType("Ja");
                    ButtonType buttonTypeNein = new ButtonType("Nein");
                    ButtonType buttonTypeAbbrechen = new ButtonType("Abbrechen");

                    Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);
                    deleteAlert.setTitle("Benutzer löschen");
                    deleteAlert.setHeaderText("Soll der Benutzer wirklich gelöscht werden?");

                    deleteAlert.getButtonTypes().setAll(buttonTypeJa, buttonTypeNein, buttonTypeAbbrechen);

                    Optional<ButtonType> result = deleteAlert.showAndWait();

                    if (result.get() == buttonTypeJa) {
                        NutzerCtl nCtl = new NutzerCtl();
                        nCtl.delete(nutzer);

                        tableViewNutzer.getItems().remove(tableViewNutzer.getSelectionModel().getSelectedItem());

                        showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Erfolgreich", "Benutzer wurde erfolgreich "
                                + "gelöscht!");
                    }
                } else {

                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Kein Benutzer ausgewählt!");
                }

            } catch (NullPointerException ex) {

            }
        });
    }

    /**
     * Aendert die Rolle eines Benutzers in Admin oder Spieler. Anschließend
     * wird das TableView aktualisiert. Wurde kein Benutzer ausgewaehlt, wird
     * eine entsprechende Fehlermeldung angzeigt.
     *
     * @author Franziska Wuttig
     */
    private void btnEventNutzerRolleAendern() {
        buttonNutzerRolleZuweisen.setOnAction(e -> {
            try {
                NutzerEntity nutzer = tableViewNutzer.getSelectionModel().getSelectedItem();
                if (nutzer.isRolle() == false) {
                    ButtonType buttonTypeJa = new ButtonType("Ja");
                    ButtonType buttonTypeNein = new ButtonType("Nein");
                    ButtonType buttonTypeAbbrechen = new ButtonType("Abbrechen");

                    Alert adminAlert = new Alert(Alert.AlertType.CONFIRMATION);
                    adminAlert.setTitle("Benutzer Rolle in Admin ändern?");
                    adminAlert.setHeaderText("Soll die Benutzer Rolle in Admin geändert werden?");

                    adminAlert.getButtonTypes().setAll(buttonTypeJa, buttonTypeNein, buttonTypeAbbrechen);

                    Optional<ButtonType> result = adminAlert.showAndWait();

                    if (result.get() == buttonTypeJa) {
                        nutzer.setRolle(true);
                        NutzerCtl nCtl = new NutzerCtl();
                        nCtl.update(nutzer);

                        showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Erfolgreich!", "Die Benutzerrolle wurde "
                                + "erfolgreich in Admin geändert!");

                        refreshTableView();
                    }
                } else {
                    ButtonType buttonTypeJa = new ButtonType("Ja");
                    ButtonType buttonTypeNein = new ButtonType("Nein");
                    ButtonType buttonTypeAbbrechen = new ButtonType("Abbrechen");

                    Alert spielerAlert = new Alert(Alert.AlertType.CONFIRMATION);
                    spielerAlert.setTitle("Benutzer Rolle in Spieler ändern?");
                    spielerAlert.setHeaderText("Soll die Benutzer Rolle in Spieler geändert werden?");

                    spielerAlert.getButtonTypes().setAll(buttonTypeJa, buttonTypeNein, buttonTypeAbbrechen);

                    Optional<ButtonType> result = spielerAlert.showAndWait();

                    if (result.get() == buttonTypeJa) {
                        nutzer.setRolle(false);
                        NutzerCtl nCtl = new NutzerCtl();
                        nCtl.update(nutzer);

                        showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Erfolgreich", "Die Benutzerrolle wurde "
                                + "erfolgreich in Spieler geändert!");

                        refreshTableView();
                    }
                }
            } catch (NullPointerException ex) {
                showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Kein Benutzer ausgewählt!");
            }
        });
    }

    /**
     * Aendert die Aktivitaet eines Benutzers in gesperrt oder frei.
     * Anschließend wird das TableView aktualisiert. Wurde kein Benutzer
     * ausgewaehlt wird eine entsprechende Fehlermeldung angezeigt.
     *
     * @author Franziska Wuttig
     */
    private void btnEventAktivitaetAendern() {
        buttonNutzerSperrenEntsperren.setOnAction(e -> {
            try {
                NutzerEntity nutzer = tableViewNutzer.getSelectionModel().getSelectedItem();
                if (nutzer.isGesperrt() == true) {
                    ButtonType buttonTypeJa = new ButtonType("Ja");
                    ButtonType buttonTypeNein = new ButtonType("Nein");
                    ButtonType buttonTypeAbbrechen = new ButtonType("Abbrechen");

                    Alert entsperrenAlert = new Alert(Alert.AlertType.CONFIRMATION);
                    entsperrenAlert.setTitle("Benutzer freigeben?");
                    entsperrenAlert.setHeaderText("Soll der Benutzer freigegeben werden?");

                    entsperrenAlert.getButtonTypes().setAll(buttonTypeJa, buttonTypeNein, buttonTypeAbbrechen);

                    Optional<ButtonType> result = entsperrenAlert.showAndWait();

                    if (result.get() == buttonTypeJa) {
                        nutzer.setGesperrt(false);
                        NutzerCtl nCtl = new NutzerCtl();
                        nCtl.update(nutzer);

                        showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Erfolgreich", "Der Benutzer wurde "
                                + "freigegeben!");

                        refreshTableView();
                    }
                } else {
                    ButtonType buttonTypeJa = new ButtonType("Ja");
                    ButtonType buttonTypeNein = new ButtonType("Nein");
                    ButtonType buttonTypeAbbrechen = new ButtonType("Abbrechen");

                    Alert sperrenAlert = new Alert(Alert.AlertType.CONFIRMATION);
                    sperrenAlert.setTitle("Benutzer sperren?");
                    sperrenAlert.setHeaderText("Soll der Benutzer gesperrt werden?");

                    sperrenAlert.getButtonTypes().setAll(buttonTypeJa, buttonTypeNein, buttonTypeAbbrechen);

                    Optional<ButtonType> result = sperrenAlert.showAndWait();

                    if (result.get() == buttonTypeJa) {
                        nutzer.setGesperrt(true);
                        NutzerCtl nCtl = new NutzerCtl();
                        nCtl.update(nutzer);

                        showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Erfolgreich", "Der Benutzer wurde gesperrt!");

                        refreshTableView();
                    }
                }
            } catch (NullPointerException ex) {
                showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Kein Benutzer ausgewählt!");
            }
        });
    }

    /**
     * Nach Klick auf den Button erfolgt die Weiterleitung zum Fenster um einen
     * neuen Benutzer anzulegen.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonNutzerAnlegenEvent() {
        buttonNutzerAnlegen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                NutzerAnlegenGUI nutzerAnlegen = new NutzerAnlegenGUI();
                nutzerAnlegen.start();
            }
        });
    }

    /**
     * Nach Klick auf den Button erfolgt die Weiterleitung zum
     * Adminverwaltungsbereich.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonZurueckEvent() {
        buttonZurueck.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                AdminVerwaltungGUI adminVerwaltung = new AdminVerwaltungGUI();
                adminVerwaltung.start();
            }
        });
    }

    /**
     * Alert wird dargestellt. Dabei wird dem Alert verschiedene Eigenschaften
     * festgelegt.
     *
     * @author Franziska Wuttig
     * @param alertType Gibt den Typ des Alerts an.
     * @param owner Gibt den 'Besitzer'/Zugehoerigkeit des Alerts an.
     * @param title Gibt den Titel des Alerts an.
     * @param message Gibt die Nachricht an, die angezeigt werden soll.
     */
    public void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
    
    /**
     * Zeigt das Fenster an.
     *
     * @author Mert-Can Kocabas
     */
    public void start() {
        Scene scene = new Scene(borderPane, 800, 800);

        Main.getPrimaryStage().setMaximized(false);
        Main.getPrimaryStage().setResizable(false);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }

    /**
     *
     * @return gibt das BorderPane zurueck.
     *
     * @author Mert-Can Kocabas
     */
    public BorderPane getBorderPaneNutzerverwaltung() {
        return borderPane;
    }

}
