package bws.gui;

import bws.gui.main.Main;
import bws.datenmodell.NutzerEntity;
import bws.datenmodell.ctls.NutzerCtl;
import static bws.gui.StartseiteGUI.logo;
import bws.logik.UserRegisterLogik;

import java.util.Arrays;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;
import javax.persistence.NoResultException;

/**
 *
 * @author Franziska Wuttig
 */
public class PasswordAendernGUI {

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * Button um Passwort zu aendern.
     */
    private Button changePasswordButton;

    /**
     * Button um Vorgang abzubrechen.
     */
    private Button abbrechenButton;

    /**
     * GridPane, welches den Inhalt der Kopfzeile beinhaltet.
     */
    private GridPane gridPaneHeaderRow;

    /**
     * GridPane, welches die Eingabemaske beinhaltet.
     */
    private GridPane gridPaneEingabemaske;

    /**
     * GridPane fuer die Buttons, die nicht in der Fußleiste seien sollen.
     */
    private GridPane gridPaneCenterButtons;

    /**
     * GridPane, welches den Inhalt der Fußleiste beinhaltet.
     */
    private GridPane footerGrid;

    /**
     * Label zur Darstellung des Seitentitels.
     */
    private Label titelLabel;

    /**
     * Label fuer das Benutzername-Eingabefeld.
     */
    private Label usernameLabel;

    /**
     * Label fuer das Passwort-Eingabefeld des alten Passwortes.
     */
    private Label oldPasswordLabel;

    /**
     * Label fuer das Passwort-Eingabefeld des neuen Passwortes.
     */
    private Label newPasswordLabel;

    /**
     * Label fuer das Passwort-Wiederholen-Eingabefeld des neuen Passwortes.
     */
    private Label repeatNewPasswordLabel;

    /**
     * Benutzername-Eingabefeld.
     */
    private TextField usernameTextField;

    /**
     * Passwort-Eingabefeld fuer das Passwort welches geaendert werden soll.
     */
    private PasswordField oldPasswordField;

    /**
     * Passwort-Eingabefeld fuer das neue Passwort.
     */
    private PasswordField newPasswordField;

    /**
     * Passwort-Wiederholung-Eingabefeld fuer das neue Passwort.
     */
    private PasswordField repeatNewPasswordField;

    /**
     * Nimmt das Eingabemasken-Grid und das Button-Grid auf.
     */
    private VBox centerVBox;

    /**
     * Konstruktor der Klasse.
     *
     * @author Franziska Wuttig
     */
    public PasswordAendernGUI() {
        initLabels();
        initButtons();
        initEingabemaskeFields();
        initGridHeaderRow();
        initGridEingabemaske();
        initGridCenterButtons();
        initCenterVBox();
        initFooterGrid();
        initBorderPane();

        abbrechenButtonEvent();
        changePasswordEvent();
    }

    /**
     * Initialisierung der Labels.
     *
     * @author Franziska Wuttig
     */
    private void initLabels() {
        titelLabel = new Label("Passwort ändern");
        usernameLabel = new Label("Username");
        oldPasswordLabel = new Label("altes Passwort");
        newPasswordLabel = new Label("neues Passwort");
        repeatNewPasswordLabel = new Label("neues Passwort wiederholen");
    }

    /**
     * Initialisierung der Buttons.
     *
     * @author Franziska Wuttig
     */
    private void initButtons() {
        changePasswordButton = new Button("Passwort ändern");
        abbrechenButton = new Button("Zurück");
    }

    /**
     * Initialisierung der Eingabemaskefelder.
     *
     * @author Franziska Wuttig
     */
    private void initEingabemaskeFields() {
        usernameTextField = new TextField();
        oldPasswordField = new PasswordField();
        newPasswordField = new PasswordField();
        repeatNewPasswordField = new PasswordField();

        Tooltip tooltipPasswort = new Tooltip("Das Passwort muss mindestens 8 Zeichen lang sein.\n"
                + "Das Passwort muss mindestens einen Großbuchstaben enthalten.\n"
                + "Das Passwort muss mindestens einen Kleinbuchstaben enthalten.\n"
                + "Das Passwort muss mindestens eine Ziffer enthalten.\n"
                + "Das Passwort kann, muss aber nicht, Sonderzeichen enthalten.");

        newPasswordField.setTooltip(tooltipPasswort);
    }

    /**
     * Initialisierung des Kopfzeilen-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franiska Wuttig
     */
    private void initGridHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);
        gridPaneHeaderRow.setStyle("-fx-font-size: 20pt;");

        gridPaneHeaderRow.setAlignment(Pos.CENTER);
        gridPaneHeaderRow.setHalignment(logo, HPos.CENTER);

        gridPaneHeaderRow.add(logo, 0, 0);
        gridPaneHeaderRow.add(titelLabel, 0, 1);
    }

    /**
     * Initialisierung des Eingabemaske-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initGridEingabemaske() {
        gridPaneEingabemaske = new GridPane();

        gridPaneEingabemaske.setPadding(new Insets(10, 10, 10, 15));
        gridPaneEingabemaske.setHgap(5);
        gridPaneEingabemaske.setVgap(5);

        gridPaneEingabemaske.setAlignment(Pos.CENTER);

        gridPaneEingabemaske.add(usernameLabel, 0, 0);
        gridPaneEingabemaske.add(usernameTextField, 0, 1);

        gridPaneEingabemaske.add(oldPasswordLabel, 0, 2);
        gridPaneEingabemaske.add(oldPasswordField, 0, 3);

        gridPaneEingabemaske.add(newPasswordLabel, 0, 4);
        gridPaneEingabemaske.add(newPasswordField, 0, 5);

        gridPaneEingabemaske.add(repeatNewPasswordLabel, 0, 6);
        gridPaneEingabemaske.add(repeatNewPasswordField, 0, 7);
    }

    /**
     * Initialisierung des Center-Buttons-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initGridCenterButtons() {
        gridPaneCenterButtons = new GridPane();
        
        gridPaneCenterButtons.setPadding(new Insets(10, 10, 10, 15));
        gridPaneCenterButtons.setHgap(5);
        gridPaneCenterButtons.setVgap(5);

        gridPaneCenterButtons.setAlignment(Pos.CENTER);

        changePasswordButton.setMaxWidth(Double.MAX_VALUE);

        gridPaneCenterButtons.add(changePasswordButton, 0, 0);
    }

    /**
     * Initialisierung der VBox, die die EingabeMaske und die Buttons aufnimmt.
     * Der VBox wird das GridPane der Eingabemaske und das GridPane der Buttons
     * hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initCenterVBox() {
        centerVBox = new VBox();
        centerVBox.getChildren().addAll(gridPaneEingabemaske, gridPaneCenterButtons);
    }

    /**
     * Initialisierung des Fußleisten-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initFooterGrid() {
        footerGrid = new GridPane();
        
        footerGrid.setPadding(new Insets(10, 10, 10, 15));
        footerGrid.setHgap(5);
        footerGrid.setVgap(5);

        footerGrid.setAlignment(Pos.CENTER_RIGHT);

        footerGrid.add(abbrechenButton, 0, 0);
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Franziska Wuttig
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(centerVBox);
        borderPane.setBottom(footerGrid);

        borderPane.setPadding(new Insets(15, 15, 15, 15));
        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Aendert das Passwort eines Nutzers. Prueft ob in den Eingabefeldern
     * korrekte Werte sind. Leitet nach erfolgreicher Erstellung weiter zur
     * Startseite.
     *
     * @author Franziska Wuttig
     */
    private void changePasswordEvent() {
        changePasswordButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (usernameTextField.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Benutzername ist ungültig!");
                    clearFields();
                    return;
                }
                if (oldPasswordField.getText().isEmpty() || newPasswordField.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Password ist ungültig!");
                    oldPasswordField.clear();
                    clearFields();
                    return;
                }

                if (repeatNewPasswordField.getText().isEmpty() || !repeatNewPasswordField.getText().equals(newPasswordField.getText())) {
                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Passwörter stimmen nicht überein!");
                    clearFields();
                    return;
                }

                try {
                    NutzerCtl nCtl = new NutzerCtl();
                    NutzerEntity nutzer = new NutzerEntity();

                    nutzer = nCtl.find(usernameTextField.getText());

                    byte[] passwortVerschlusselt = UserRegisterLogik.verschlusseln(oldPasswordField.getText());

                    if (Arrays.equals(passwortVerschlusselt, nutzer.getPassword())) {
                        if (newPasswordField.getText().matches("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$")) {
                            nutzer.setPassword(UserRegisterLogik.verschlusseln(newPasswordField.getText()));

                            nCtl.update(nutzer);
                            showAlert(Alert.AlertType.INFORMATION, borderPane.getScene().getWindow(), "Erfolgreich!", "Die Änderung des Passwords war erfolgreich!");

                            StartseiteGUI startseiteGUI = new StartseiteGUI();
                            startseiteGUI.start();
                        } else {
                            showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Passwort überprüfen", "Bitte überprüfe ob dein Passwort alle Kriterien erfüllt.");
                        }
                    }
                } catch (NullPointerException | NoResultException ex) {
                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Fehlgeschlagen!", "Benutzername und Password prüfen!");
                    clearFields();
                }
            }
        });
    }

    /**
     * Weiterleitung zur Startseite.
     *
     * @author Franziska Wuttig
     */
    private void abbrechenButtonEvent() {
        abbrechenButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                StartseiteGUI startseite = new StartseiteGUI();
                startseite.start();
            }
        });
    }

    /**
     * Alert wird dargestellt. Dabei wird dem Alert verschiedene Eigenschaften
     * festgelegt.
     *
     * @author Franziska Wuttig
     * @param alertType Gibt den Typ des Alerts an.
     * @param owner Gibt den 'Besitzer'/Zugehoerigkeit des Alerts an.
     * @param title Gibt den Titel des Alerts an.
     * @param message Gibt die Nachricht an, die angezeigt werden soll.
     */
    private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    /**
     * Methode zum Leeren der Textfelder fuer Username, altes Passwort, neues
     * Passwort und Passwortwiederholung des neuen Passwortes.
     *
     * @author Franziska Wuttig
     */
    private void clearFields() {
        usernameTextField.clear();
        oldPasswordField.clear();
        newPasswordField.clear();
        repeatNewPasswordField.clear();
    }

    /**
     * Zeigt das Fenster an.
     *
     * @author Franziska Wuttig
     */
    public void start() {
        Scene scene = new Scene(borderPane, 500, 650);

        Main.getPrimaryStage().setTitle("Wo liegt das?");
        Main.getPrimaryStage().setResizable(false);
        Main.getPrimaryStage().setMaximized(false);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }
}
