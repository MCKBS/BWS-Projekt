package bws.gui;

import bws.gui.main.Main;


import bws.datenmodell.FrageEntity;
import bws.datenmodell.ctls.FrageCtl;

import static bws.gui.StartseiteGUI.logo;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import javafx.collections.ObservableList;

import javafx.concurrent.Worker;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

import javafx.stage.Stage;
import javafx.stage.Window;

/**
 * @author Mert-Can Kocabas
 */
public class FragenBearbeitungGUI {

    /**
     * Gibt letzendlich an ob die Karte zu Beginn der Bearbeitung einmal geladen
     * wurde. Ohne einer zusätzlichen Prüfung mit dieser Variabl in der
     * 'changed'-Methode, wird die Karte immer auf die ursprüngliche Karte
     * gewechselt, wenn man der Frage eine neue Karte zuweisen will.
     *
     */
    private Boolean onlyOnce;

    /**
     * Beinhaltet die komplette View des Fensters.
     */
    private BorderPane borderPane;

    /**
     * Button um die Frage zu speichern.
     */
    private Button buttonFrageSpeichern;

    /**
     * Button um zurück auf die Adminverwaltung zu kommen, ohne die Frage zu
     * speichern.
     */
    private Button buttonAbbrechen;

    /**
     * ChoiceBox für die Karten.
     */
    private ChoiceBox<String> choiceBoxKarte;

    /**
     * Nimmt die zu bearbeitende Frage aus der Datenbank auf.
     */
    private FrageEntity frage;

    /**
     * GridPane, welches den Inhalt der Kopfzeile beinhaltet.
     */
    private GridPane gridPaneHeaderRow;

    /**
     * GridPane, welches die Felder zum Bearbeiten enthält.
     */
    private GridPane gridPaneFrageBearbeiten;

    /**
     * Label zur Darstellung des Seitentitels.
     */
    private Label labelTitel;

    /**
     * Label für das Eingabefeld der Frage.
     */
    private Label labelFrageBearbeiten;

    /**
     * Label für das Eingabefeld der Antwort von der Frage.
     */
    private Label labelAntwortBearbeiten;

    /**
     * Label für die ChoiceBox der Karte.
     */
    private Label labelKarteAuswahl;

    /**
     * Nimmt die Karten der ChoiceBox an.
     */
    private ObservableList<String> observableList;

    /**
     * Eingabefeld für die Frage.
     */
    private TextField textFieldFrage;

    /**
     * Eingabefeld für die Antwort der Frage.
     */
    private TextField textFieldAntwort;

    /**
     * Array, mit den relativen Pfadangaben der Spielkarten.
     */
    private String relPathMap[];

    /**
     * Dient als "Verbindungsstück" zwischen JavaFX und HTML.
     */
    private WebEngine webEngine;

    /**
     * Stellt das HTML-Dokument in JavaFX dar.
     */
    private WebView browser;

    /**
     * Konstruktor der Klasse.
     *
     * @author Mert-Can Kocabas
     */
    public FragenBearbeitungGUI() {
        initWebView();
        initWebEngine();
        initLabels();
        initButtons();
        initTextFields();
        initRelPathMap();
        initObservableList();

        initGridPaneHeaderRow();
        initGridPaneRightColumn();
        initBorderPane();

        changeMapViaChoiceBox();

        buttonFrageSpeichern();
        buttonAbbrechenEvent();
    }

    /**
     * Initialisierung der WebView.
     *
     * @author Mert-Can Kocabas
     */
    private void initWebView() {
        browser = new WebView();
    }

    /**
     * Initialisierung der WebEngine.
     *
     * @author Mert-Can Kocabas
     */
    private void initWebEngine() {
        webEngine = new WebEngine();
        webEngine = browser.getEngine();
    }

    /**
     * Initialisierung der Labels.
     *
     * @author Mert-Can Kocabas
     */
    private void initLabels() {
        labelTitel = new Label("Frage bearbeiten");
        labelFrageBearbeiten = new Label("Frage eingeben");
        labelAntwortBearbeiten = new Label("Antwort eingeben");
        labelKarteAuswahl = new Label("Karte auswählen");
    }

    /**
     * Initialisierung der Buttons.
     *
     * @author Mert-Can Kocabas
     */
    private void initButtons() {
        buttonFrageSpeichern = new Button("Frage speichern");
        buttonAbbrechen = new Button("Abbrechen");
    }

    /**
     * Initialisierung der Eingabefelder.
     *
     * @author Mert-Can Kocabas
     */
    private void initTextFields() {
        textFieldFrage = new TextField();
        textFieldAntwort = new TextField();
    }

    /**
     * Initialisierung des Arrays für die relativen Pfadangaben der Karten.
     *
     * @author Mert-Can Kocabas
     */
    private void initRelPathMap() {
        relPathMap = new String[]{
            this.getClass().getResource("/bws/resources/leaflet/weltMap.html").toExternalForm(),
            this.getClass().getResource("/bws/resources/leaflet/europaMap.html").toExternalForm(),
            this.getClass().getResource("/bws/resources/leaflet/deutschlandMap.html").toExternalForm()
        };
    }

    /**
     * Initialisierung der ObservableList.
     *
     * @author Mert-Can Kocabas
     */
    private void initObservableList() {
        choiceBoxKarte = new ChoiceBox<String>();
        
        observableList = choiceBoxKarte.getItems();
        observableList.addAll("Weltkarte", "Europakarte", "Deutschlandkarte");
    }

    /**
     * Initialisierung des Kopfzeilen-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);

        gridPaneHeaderRow.setAlignment(Pos.CENTER);
        gridPaneHeaderRow.setStyle("-fx-font-size: 20pt;");

        gridPaneHeaderRow.add(labelTitel, 0, 0);
    }

    /**
     * Initialisierung des Eingabemaske-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneRightColumn() {
        gridPaneFrageBearbeiten = new GridPane();

        gridPaneFrageBearbeiten.setPadding(new Insets(10, 10, 10, 15));
        gridPaneFrageBearbeiten.setHgap(5);
        gridPaneFrageBearbeiten.setVgap(5);

        gridPaneFrageBearbeiten.setAlignment(Pos.TOP_CENTER);

        gridPaneFrageBearbeiten.add(logo, 0, 0);

        gridPaneFrageBearbeiten.add(labelFrageBearbeiten, 0, 1);
        gridPaneFrageBearbeiten.add(textFieldFrage, 0, 2);

        gridPaneFrageBearbeiten.add(labelAntwortBearbeiten, 0, 3);
        gridPaneFrageBearbeiten.add(textFieldAntwort, 0, 4);

        gridPaneFrageBearbeiten.add(labelKarteAuswahl, 0, 5);
        gridPaneFrageBearbeiten.add(choiceBoxKarte, 0, 6);

        gridPaneFrageBearbeiten.add(buttonFrageSpeichern, 0, 7);

        gridPaneFrageBearbeiten.add(buttonAbbrechen, 0, 8);
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setRight(gridPaneFrageBearbeiten);
        borderPane.setCenter(browser);

        borderPane.setPadding(new Insets(5, 0, 0, 0));
        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Ändert die Karte, abhängig von der gewählten Karte in der ChoiceBox.
     *
     * @author Mert-Can Kocabas
     */
    private void changeMapViaChoiceBox() {
        choiceBoxKarte.getSelectionModel().selectedIndexProperty().addListener(
                ((ov, oldVal, newVal) -> {
                    webEngine.load(relPathMap[newVal.intValue()]);
                }));
    }

    /**
     * Speichert die bearbeitete Frage in der Datenbank.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonFrageSpeichern() {
        buttonFrageSpeichern.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                String latlng = (String) webEngine.executeScript("getMarkerLatLng()");
                System.out.println(latlng);
                if (textFieldFrage.getText().equals("") || textFieldAntwort.getText().equals("") || latlng.equals("undefined")) {
                    showAlert(Alert.AlertType.ERROR, borderPane.getScene().getWindow(), "Frage prüfen", "Bitte überprüfen, dass in jedem Feld etwas eingetragen ist und eine Markierung vorhanden ist.");
                } else {
                    if (latlng.equals("undefined")) {

                    } else {
                        FrageEntity frage = new FrageEntity();
                        FrageCtl frageCTL = new FrageCtl();

                        frage = getFrage();

                        frage.setFrage(textFieldFrage.getText());
                        frage.setAntwort(textFieldAntwort.getText());
                        frage.setKarte(choiceBoxKarte.getSelectionModel().getSelectedItem());
                        frage.setLatLng(latlng);

                        frageCTL.update(frage);

                        Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                        stage.close();

                        FragenVerwaltungGUI fragenVerwaltung = new FragenVerwaltungGUI();
                        fragenVerwaltung.start();
                    }
                }
            }
        });
    }

    /**
     * Bricht die Fragenbearbeitung ab und bringt den Benutzer wieder zurück zur
     * Fragenverwaltung.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonAbbrechenEvent() {
        buttonAbbrechen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                FragenVerwaltungGUI fragenVerwaltung = new FragenVerwaltungGUI();
                fragenVerwaltung.start();
            }
        });
    }

    /**
     * Setzt die Felder der Eingabemaske entsprechend der Daten von der zu
     * bearbeitenden Frage.
     *
     * @param frage Gibt die zu bearbeitende Frage an.
     * @author Mert-Can Kocabas
     */
    public void setFields(FrageEntity frage) {
        onlyOnce = false;
        setFrage(frage);
        choiceBoxKarte.getSelectionModel().select(frage.getKarte());
        webEngine.load(relPathMap[choiceBoxKarte.getSelectionModel().getSelectedIndex()]);
        
        webEngine.getLoadWorker().stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue ov, Worker.State oldState, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED && !onlyOnce) {
                    textFieldFrage.setText(frage.getFrage());
                    textFieldAntwort.setText(frage.getAntwort());
                    choiceBoxKarte.getSelectionModel().select(frage.getKarte());

                    webEngine.executeScript("placeMarkerOnMap(" + frage.getLatLng() + ")");

                    onlyOnce = true;
                }
            }
        });
    }

    /**
     * Alert wird dargestellt. Dabei wird dem Alert verschiedene Eigenschaften
     * festgelegt.
     *
     * @author Franziska Wuttig
     * @param alertType Gibt den Typ des Alerts an.
     * @param owner Gibt den 'Besitzer'/Zugehoerigkeit des Alerts an.
     * @param title Gibt den Titel des Alerts an.
     * @param message Gibt die Nachricht an, die angezeigt werden soll.
     */
    private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);

        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    /**
     * Zeigt das Fenster an.
     *
     * @author Mert-Can Kocabas
     */
    public void start() {
        StackPane root = new StackPane();

        root.getChildren().add(borderPane);

        Scene scene = new Scene(root);

        Main.getPrimaryStage().setMaximized(true);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }

    /**
     * @author Mert-Can Kocabas
     * @return Die Frage die bearbeitet werden soll.
     */
    public FrageEntity getFrage() {
        return frage;
    }

    /**
     * @author Mert-Can Kocabas
     * @param frage Gibt die zu bearbeitende Frage an.
     */
    public void setFrage(FrageEntity frage) {
        this.frage = frage;
    }
}
