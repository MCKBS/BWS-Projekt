package bws.gui;

import bws.gui.main.Main;

import bws.datenmodell.FrageEntity;
import bws.datenmodell.ctls.FrageCtl;
import static bws.gui.StartseiteGUI.logo;

import java.util.List;
import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;

import javafx.stage.Stage;
import javafx.stage.Window;

/**
 *
 * @author mertcan
 */
public class FragenVerwaltungGUI {

    private BorderPane borderPane;

    private Button buttonFrageErstellen;
    private Button buttonFrageBearbeiten;
    private Button buttonFrageLoeschen;
    private Button buttonZurueck;

    private GridPane gridPaneHeaderRow;
    private GridPane gridPaneFragenListe;
    private GridPane gridPaneFooterRow;

    private Label labelTitel;
    private Label labelFragenListe;

    private ObservableList<FrageEntity> observableList;

    /**
     * TableView für die Darstellung der Fragen aus der Datenbank.
     */
    private TableView<FrageEntity> tableViewFrage;

    /**
     * Konstruktor der Klasse.
     *
     * @author Mert-Can Kocabas
     */
    public FragenVerwaltungGUI() {
        initLabels();
        initButtons();
        initGridPaneHeaderRow();
        initTableView();
        initGridPaneFragenListe();
        initGridPaneFooterRow();
        initBorderPane();

        buttonFrageErstellenEvent();
        buttonFrageBearbeitenEvent();
        buttonFrageLoeschenEvent();
        buttonZurueckEvent();
    }

    /**
     * Initialisierung der Labels. Die Darstellung wird angepasst.
     *
     * @author Mert-Can Kocabas
     */
    private void initLabels() {
        labelTitel = new Label("Fragenverwaltung");
        labelFragenListe = new Label("Liste aller Fragen");

        labelFragenListe.setStyle("-fx-font-size: 16pt;");
    }

    /**
     * Initialisierung der Buttons.
     *
     * @author Mert-Can Kocabas
     */
    private void initButtons() {
        buttonFrageErstellen = new Button("Frage erstellen");
        buttonFrageBearbeiten = new Button("Frage bearbeiten");
        buttonFrageLoeschen = new Button("Frage Löschen");
        buttonZurueck = new Button("Zurück");
    }

    /**
     * Initialisierung des TableView der Fragen. Alle Fragen aus der Datenbank
     * werden im TableView dargestellt.
     *
     * @author Mert-Can Kocabas
     */
    private void initTableView() {
        tableViewFrage = new TableView<FrageEntity>();
        tableViewFrage.setPrefSize(600, 500);

        TableColumn<FrageEntity, String> frageColumn = new TableColumn<FrageEntity, String>("Frage");
        TableColumn<FrageEntity, String> antwortColumn = new TableColumn<FrageEntity, String>("Antwort");
        TableColumn<FrageEntity, String> karteColumn = new TableColumn<FrageEntity, String>("Karte");

        frageColumn.setCellValueFactory(new PropertyValueFactory<>("frage"));
        antwortColumn.setCellValueFactory(new PropertyValueFactory<>("antwort"));
        karteColumn.setCellValueFactory(new PropertyValueFactory<>("karte"));

        tableViewFrage.getColumns().addAll(frageColumn, antwortColumn, karteColumn);

        FrageCtl frageCTL = new FrageCtl();
        List<FrageEntity> frageList = frageCTL.findAll();

        observableList = FXCollections.observableArrayList();

        for (FrageEntity frageAusListe : frageList) {
            FrageEntity frage = new FrageEntity();

            frage.setId(frageAusListe.getId());
            frage.setFrage(frageAusListe.getFrage());
            frage.setAntwort(frageAusListe.getAntwort());
            frage.setKarte(frageAusListe.getKarte());
            frage.setLatLng(frageAusListe.getLatLng());

            observableList.add(frage);
        }
        tableViewFrage.setItems(observableList);

        tableViewFrage.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    /**
     * Initialisierung des Kopfzeilen-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneHeaderRow() {
        gridPaneHeaderRow = new GridPane();

        gridPaneHeaderRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneHeaderRow.setHgap(5);
        gridPaneHeaderRow.setVgap(5);

        gridPaneHeaderRow.setAlignment(Pos.CENTER);
        gridPaneHeaderRow.setStyle("-fx-font-size: 20pt;");

        gridPaneHeaderRow.add(logo, 0, 0);
        gridPaneHeaderRow.add(labelTitel, 0, 1);
    }

    /**
     * Initialisierung des FragenListe-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneFragenListe() {
        gridPaneFragenListe = new GridPane();

        gridPaneFragenListe.setPadding(new Insets(10, 10, 10, 15));
        gridPaneFragenListe.setHgap(5);
        gridPaneFragenListe.setVgap(5);

        gridPaneFragenListe.setAlignment(Pos.CENTER);
        gridPaneFragenListe.setHalignment(labelFragenListe, HPos.CENTER);

        gridPaneFragenListe.add(labelFragenListe, 0, 0, 3, 1);
        gridPaneFragenListe.add(tableViewFrage, 0, 1, 3, 1);
        gridPaneFragenListe.add(buttonFrageErstellen, 0, 2);
        gridPaneFragenListe.add(buttonFrageBearbeiten, 1, 2);
        gridPaneFragenListe.add(buttonFrageLoeschen, 2, 2);
    }

    /**
     * Initialisierung des Fußleisten-Grid. Die Darstellung des Grids wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initGridPaneFooterRow() {
        gridPaneFooterRow = new GridPane();

        gridPaneFooterRow.setPadding(new Insets(10, 10, 10, 15));
        gridPaneFooterRow.setHgap(5);
        gridPaneFooterRow.setVgap(5);

        gridPaneFooterRow.setAlignment(Pos.CENTER);

        gridPaneFooterRow.add(buttonZurueck, 0, 0);
    }

    /**
     * Initialisierung des Border-Pane. Die Darstellung des Border-Pane wird
     * angepasst und die jeweiligen Elemente werden hinzugefuegt.
     *
     * @author Mert-Can Kocabas
     */
    private void initBorderPane() {
        borderPane = new BorderPane();

        borderPane.setTop(gridPaneHeaderRow);
        borderPane.setCenter(gridPaneFragenListe);
        borderPane.setBottom(gridPaneFooterRow);

        borderPane.setPadding(new Insets(15, 15, 15, 15));
        borderPane.setStyle("-fx-background-color: #ffffff; -fx-font-size: 14pt;");
    }

    /**
     * Weiterleitung zur Fragen Erstellung.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonFrageErstellenEvent() {
        buttonFrageErstellen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                FragenErstellungGUI fragenErstellung = new FragenErstellungGUI();
                fragenErstellung.start();
            }
        });
    }

    /**
     * Die Ausgewählte Frage aus der Liste wird gelöscht.
     *
     * @author Franziska Wuttig
     */
    private void buttonFrageLoeschenEvent() {
        buttonFrageLoeschen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                FrageEntity frage = tableViewFrage.getSelectionModel().getSelectedItem();

                ButtonType buttonTypeJa = new ButtonType("Ja");
                ButtonType buttonTypeNein = new ButtonType("Nein");
                ButtonType buttonTypeAbbrechen = new ButtonType("Abbrechen");

                if (frage != null) {
                    Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION);
                    deleteAlert.setTitle("Frage löschen");
                    deleteAlert.setHeaderText("Soll die Frage wirklich gelöscht werden?");

                    deleteAlert.getButtonTypes().setAll(buttonTypeJa, buttonTypeNein, buttonTypeAbbrechen);

                    Optional<ButtonType> result = deleteAlert.showAndWait();

                    if (result.get() == buttonTypeJa) {
                        tableViewFrage.getItems().remove(frage);
                        FrageCtl frageCTL = new FrageCtl();
                        frageCTL.delete(frage);

                        showAlert(AlertType.INFORMATION, borderPane.getScene().getWindow(), "Erfolgreich!", "Frage wurde erfolgreich gelöscht!");
                    }
                } else {
                    showAlert(AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Keine Frage ausgewählt!");
                }
            }
        });
    }

    /**
     * Weiterleitung zur Fragen Bearbeitung.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonFrageBearbeitenEvent() {
        buttonFrageBearbeiten.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                FrageEntity frage = tableViewFrage.getSelectionModel().getSelectedItem();
                if (frage != null) {
                    Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                    stage.close();

                    FragenBearbeitungGUI fragenBearbeitung = new FragenBearbeitungGUI();
                    fragenBearbeitung.start();

                    fragenBearbeitung.setFields(frage);
                } else {
                    showAlert(AlertType.ERROR, borderPane.getScene().getWindow(), "Error!", "Keine Frage ausgewählt!");
                }
            }
        });
    }

    /**
     * Weiterleitung zur AdminVerwaltung.
     *
     * @author Mert-Can Kocabas
     */
    private void buttonZurueckEvent() {
        buttonZurueck.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Stage stage = (Stage) Main.getPrimaryStage().getScene().getWindow();
                stage.close();

                AdminVerwaltungGUI adminVerwaltung = new AdminVerwaltungGUI();
                adminVerwaltung.start();
            }
        });
    }

    /**
     * Alert wird dargestellt. Dabei wird dem Alert verschiedene Eigenschaften
     * festgelegt.
     *
     * @author Franziska Wuttig
     * @param alertType Gibt den Typ des Alerts an.
     * @param owner Gibt den 'Besitzer'/Zugehoerigkeit des Alerts an.
     * @param title Gibt den Titel des Alerts an.
     * @param message Gibt die Nachricht an, die angezeigt werden soll.
     */
    public void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

    /**
     * Zeigt das Fenster an.
     *
     * @author Mert-Can Kocabas
     */
    public void start() {
        Scene scene = new Scene(borderPane, 800, 800);

        Main.getPrimaryStage().setMaximized(false);
        Main.getPrimaryStage().setScene(scene);
        Main.getPrimaryStage().show();
    }
}
