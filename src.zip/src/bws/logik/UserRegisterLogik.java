package bws.logik;

import java.io.UnsupportedEncodingException;

import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 * @author Franziska Wuttig
 */
public final class UserRegisterLogik {

    /**
     * Das eingegebene Passwort wird verschluesselt.
     *
     * @author Franziska Wuttig
     * @param klartext Das Passwort als Klartext.
     * @return Das verschluesselte Passwort.
     */
    public static byte[] verschlusseln(String klartext) {
        byte[] verschluesselt = new byte[0];

        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");

            byte[] klartextArray = klartext.getBytes("UTF-8");

            klartextArray = messageDigest.digest(klartextArray);
            klartextArray = Arrays.copyOf(klartextArray, 16);

            SecretKeySpec secretKeySpec = new SecretKeySpec(klartextArray, "AES");

            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);

            verschluesselt = cipher.doFinal(klartext.getBytes());

        } catch (UnsupportedEncodingException
                | NoSuchAlgorithmException
                | NoSuchPaddingException
                | InvalidKeyException
                | IllegalBlockSizeException
                | BadPaddingException ex) {

            Logger.getLogger(UserRegisterLogik.class.getName()).log(Level.SEVERE, "Beim Verschl\u00fcsseln ist ein Problem aufgetreten: {0}", ex.getMessage());
        }
        return verschluesselt;
    }
}
