package bws.logik;

import bws.datenmodell.NutzerEntity;
import javafx.scene.control.TableCell;
import javafx.scene.text.Text;

/**
 *
 * @author Franziska Wuttig
 */
public class TableCellAktivitaet extends TableCell<NutzerEntity, Boolean> {

    @Override
    /**
     * @author Franziska Wuttig Ersetzt die Boolean-Werte aus der Datenbank der
     * Spalte Aktivitaet, durch Text (statt true oder false, frei oder
     * gesperrt).
     */
    public void updateItem(Boolean item, boolean empty) {
        super.updateItem(item, empty);

        if (item == null || empty) {
            setGraphic(null);
        } else {
            Text text = new Text();

            if (item != true) {
                text.setText("frei");
            } else {
                text.setText("gesperrt");
            }
            setGraphic(text);
        }
    }

}
