package bws.logik;

import bws.datenmodell.NutzerEntity;
import javafx.scene.control.TableCell;
import javafx.scene.text.Text;

/**
 * @author Franziska Wuttig
 */
public class TableCellRolle extends TableCell<NutzerEntity, Boolean> {

    @Override
    /**
     *
     * @author Franziska Wuttig
     * @param item
     * @param empty
     * @param rolle
     *
     * Ersetzt die Boolean-Werte aus der Datenbank der Spalte Rolle, durch Text
     * (statt true oder false, Admin oder Spieler).
     */
    protected void updateItem(Boolean item, boolean empty) {
        super.updateItem(item, empty);

        if (item == null || empty) {
            setGraphic(null);
        } else {
            Text text = new Text();

            if (item != true) {
                text.setText("Spieler");
            } else {
                text.setText("Admin");
            }
            setGraphic(text);
        }
    }
}
