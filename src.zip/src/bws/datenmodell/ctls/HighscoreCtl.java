package bws.datenmodell.ctls;

import bws.datenmodell.HighscoreEntity;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

/**
 * @author Mert-Can Kocabas
 */
public class HighscoreCtl {
    
    /**
     * Die EntityManagerFactory.
     */
    private EntityManagerFactory entityManagerFactory = null;
    
     /**
     * Der EntityManager.
     */
    private EntityManager entityManager = null;
    
     /**
     * Der CriteriaBuilder.
     */
    private CriteriaBuilder criteriaBuilder = null;
    
    /**
     * Es wird eine neue EntityManagerFactory erstellt. Diese erstellt wiederum einen neuen EntityManager als Schnittstelle zur Persistenzschicht.
     * Der EntityManager ruft den CriteriaBuilder ab um CriteriaQuery Objekte und ihre Ausdrücke zu erstellen.
     * 
     * @author Mert-Can Kocabas
     */
    public HighscoreCtl() {
        entityManagerFactory = Persistence.createEntityManagerFactory("WoLiegtDasPU");
        entityManager = entityManagerFactory.createEntityManager();
        criteriaBuilder = entityManager.getCriteriaBuilder();
    }
    
    /**
     * Erstell einen Highscore.
     * 
     * @author Mert-Can Kocabas
     * @param <T> Kann ein beliebiger Datentyp sein.
     * @param highscore Der Highscore der erstellt werden soll.
     */
    public <T> void create(HighscoreEntity highscore) {
        if (highscore instanceof HighscoreEntity) {
            entityManager.getTransaction().begin();
            entityManager.persist(highscore);
            entityManager.getTransaction().commit();
        } else {
            System.err.println("Kein gültiger Datentyp angegeben");
        }
    }
    
    /**
     * Gibt eine Liste aller Fragen zurück.
     * 
     * @author Mert-Can Kocabas
     * @return Gibt eine ArrayList aller Fragen zurück.
     */
    public List<HighscoreEntity> findAll() {
        CriteriaQuery<HighscoreEntity> query = criteriaBuilder.createQuery(HighscoreEntity.class);
        Query q = entityManager.createQuery(query);
        
        return new ArrayList<>(q.getResultList());
    }
}