package bws.datenmodell.ctls;

import bws.datenmodell.NutzerEntity;
import bws.datenmodell.NutzerEntity_;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * @author Mert-Can Kocabas
 */
public class NutzerCtl {

    /**
     * Die EntityManagerFactory.
     */
    private EntityManagerFactory entityManagerFactory = null;
    
     /**
     * Der EntityManager.
     */
    private EntityManager entityManager = null;
    
     /**
     * Der CriteriaBuilder.
     */
    private CriteriaBuilder criteriaBuilder = null;

    /**
     * Es wird eine neue EntityManagerFactory erstellt. Diese erstellt wiederum einen neuen EntityManager als Schnittstelle zur Persistenzschicht.
     * Der EntityManager ruft den CriteriaBuilder ab um CriteriaQuery Objekte und ihre Ausdrücke zu erstellen.
     * 
     * @author Mert-Can Kocabas
     */
    public NutzerCtl() {
        entityManagerFactory = Persistence.createEntityManagerFactory("WoLiegtDasPU");
        entityManager = entityManagerFactory.createEntityManager();
        criteriaBuilder = entityManager.getCriteriaBuilder();
    }

    /**
     * Ein neuer Benutzer wird erstellt.
     * 
     * @author Mert-Can Kocabas
     * @param <T> Kann ein beliebiger Datentyp sein.
     * @param nutzer Der Benutzer, der erstellt werden soll.
     * @throws RollbackException wird ausgelöst, wenn die Transaktion nicht durchgeführt werden konnte.
     */
    public <T> void create(NutzerEntity nutzer) throws RollbackException{
        if (nutzer instanceof NutzerEntity) {
            entityManager.getTransaction().begin();
            entityManager.persist(nutzer);
            entityManager.getTransaction().commit();
        } else {
            System.err.println("Kein gültiger Datentyp angegeben");
        }
    }

    /**
     * Aktualisiert einen Benutzer.
     * 
     * @author Mert-Can Kocabas
     * @param <T> Kann ein beliebiger Datentyp sein.
     * @param nutzer Der Benutzer, der aktualisiert werden soll.
     */
    public <T> void update(NutzerEntity nutzer) {
        if (nutzer instanceof NutzerEntity) {
            entityManager.getTransaction().begin();
            entityManager.merge(nutzer);
            entityManager.getTransaction().commit();
        } else {
            System.err.println("Kein gültiger Datentyp angegeben");
        }
    }

    /**
     * Löscht einen Benutzer.
     * 
     * @author Mert-Can Kocabas
     * @param <T> Kann ein beliebiger Datentyp sein.
     * @param nutzer Der Benutzer, der gelöscht werden soll.
     */
    public <T> void delete(NutzerEntity nutzer) {
        if (nutzer instanceof NutzerEntity) {
            entityManager.getTransaction().begin();
            NutzerEntity n = entityManager.getReference(NutzerEntity.class, nutzer.getId());
            entityManager.remove(n);
            nutzer = null;
            n = null;
            entityManager.getTransaction().commit();
        } else {
            System.err.println("Kein gültiger Datentyp angegeben");
        }
    }

    /**
     * Sucht nach einem Benutzer.
     * 
     * @author Mert-Can Kocabas
     * @param username Benutzername nach dem gesucht werden soll.
     * @return Gibt einen einzelnen Benutzernamen zurück.
     * @throws NoResultException Wird ausgelöst, wenn der Username nicht gefunden werden konnte.
     */
    public NutzerEntity find(String username) throws NoResultException {
        CriteriaQuery<NutzerEntity> cq = criteriaBuilder.createQuery(NutzerEntity.class);
        Root<NutzerEntity> root = cq.from(NutzerEntity.class);

        Predicate predicate = criteriaBuilder.equal(root.get(NutzerEntity_.username), username);
        cq.where(predicate);

        return entityManager.createQuery(cq).getSingleResult();
    }
    
    /**
     * Gibt die Liste aller Benutzer zurück.
     * 
     * @author Mert-Can Kocabas
     * @return Gibt eine ArrayListe aller Benutzer zurück.
     */
    public List<NutzerEntity> findAll() {
        CriteriaQuery<NutzerEntity> query = criteriaBuilder.createQuery(NutzerEntity.class);
        Query q = entityManager.createQuery(query);
        return new ArrayList<>(q.getResultList());
    }
}