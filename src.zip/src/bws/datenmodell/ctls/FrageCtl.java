package bws.datenmodell.ctls;

import bws.datenmodell.FrageEntity;
import bws.datenmodell.FrageEntity_;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * @author Mert-Can Kocabas
 */
public class FrageCtl {
    
    /**
     * Die EntityManagerFactory.
     */
    private EntityManagerFactory entityManagerFactory = null;
    
     /**
     * Der EntityManager.
     */
    private EntityManager entityManager = null;
    
     /**
     * Der CriteriaBuilder.
     */
    private CriteriaBuilder criteriaBuilder = null;
    
    /**
     * Es wird eine neue EntityManagerFactory erstellt. Diese erstellt wiederum einen neuen EntityManager als Schnittstelle zur Persistenzschicht.
     * Der EntityManager ruft den CriteriaBuilder ab um CriteriaQuery Objekte und ihre Ausdrücke zu erstellen.
     * 
     * @author Mert-Can Kocabas
     */
    public FrageCtl() {
        entityManagerFactory = Persistence.createEntityManagerFactory("WoLiegtDasPU");
        entityManager = entityManagerFactory.createEntityManager();
        criteriaBuilder = entityManager.getCriteriaBuilder();
    }
    
    /**
     * Erstellt eine neue Frage.
     * 
     * @author Mert-Can Kocabas
     * @param <T> Kann ein beliebiger Datentyp sein.
     * @param frage Die Frage, die erstellt werden soll.
     */
    public <T> void create(FrageEntity frage) {
        if (frage instanceof FrageEntity) {
            entityManager.getTransaction().begin();
            entityManager.persist(frage);
            entityManager.getTransaction().commit();
        } else {
            System.err.println("Kein gültiger Datentyp angegeben");
        }
    }

    /**
     * Aktualisiert eine Frage.
     * 
     * @author Mert-Can Kocabas
     * @param <T> Kann ein beliebiger Datentyp sein.
     * @param frage Die Frage, die aktualisiert werden soll.
     */
    public <T> void update(FrageEntity frage) {
        if (frage instanceof FrageEntity) {
            entityManager.getTransaction().begin();
            entityManager.merge(frage);
            entityManager.getTransaction().commit();
        } else {
            System.err.println("Kein gültiger Datentyp angegeben");
        }
    }

    /**
     * Löscht eine Frage.
     * 
     * @author Mert-Can Kocabas
     * @param <T> Kann ein beliebiger Datentyp sein.
     * @param frage Die Frage, die gelöscht werden soll.
     */
    public <T> void delete(FrageEntity frage) {
        if (frage instanceof FrageEntity) {
            entityManager.getTransaction().begin();
            FrageEntity f = entityManager.getReference(FrageEntity.class, frage.getId());
            entityManager.remove(f);
            frage = null;
            f = null;
            entityManager.getTransaction().commit();
        } else {
            System.err.println("Kein gültiger Datentyp angegeben");
        }
    }
    
    /**
     * Gibt eine Liste der Fragen zu der jeweiligen Karte zurück.
     * 
     * @author Mert-Can Kocabas
     * @param karte Die Karte zu der die jeweiligen Fragen gesucht werden sollen.
     * @return Gibt eine ArrayList der Fragen zu der jeweiligen Karte zurück.
     */
    public List<FrageEntity> find(String karte) {
        CriteriaQuery<FrageEntity> cq = criteriaBuilder.createQuery(FrageEntity.class);
        Root<FrageEntity> root = cq.from(FrageEntity.class);

        Predicate predicate = criteriaBuilder.equal(root.get(FrageEntity_.karte), karte);
        cq.where(predicate);
        Query q = entityManager.createQuery(cq);

        return new ArrayList<>(q.getResultList());
    }
    
    /**
     * Gibt eine Liste aller Fragen zurück.
     * 
     * @author Mert-Can Kocabas
     * @return Gibt eine ArrayList aller Fragen zurück.
     */
    public List<FrageEntity> findAll() {
        CriteriaQuery<FrageEntity> query = criteriaBuilder.createQuery(FrageEntity.class);
        Query q = entityManager.createQuery(query);
        
        return new ArrayList<>(q.getResultList());
    }
}