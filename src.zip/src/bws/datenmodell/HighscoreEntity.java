package bws.datenmodell;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @Entity Annotation macht kenntlich, dass diese Klasse von JPA persistiert
 * werden soll.
 * @Table ordnet die Entitätsklasse der gleichnamigen Tabelle in der Datenbank
 * zu.
 *
 * @author Franziska Wuttig
 */
@Entity
@Table(name = "highscore")
public class HighscoreEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * @Id kennzeichnet den Primärschlüssel
     * @GeneratedValue bedeutet, dass dieser automatisch generiert werden soll
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    /**
     * @ManyToOne definiert die Assoziation zu der Entitätsklasse NutzerEntity
     */
    @ManyToOne()
    /**
     * Objekt der Entitätsklasse NutzerEntity
     */
    private NutzerEntity spieler;

     /**
     * @Column passt die Zuordnung zwischen dem Entitätsattribut und der
     * Datenbankspalte an. columnDefinition definiert ein SQL-Fragment, das
     * während der Tabellendefinition verwendet wird. nullable legt fest, das
     */
    @Column(columnDefinition = "int default 0")
    /**
     * Spalte Punkte der Tabelle Highscore. Enthält die Punkte eines Spielers.
     */
    private int punkte;

    /**
     * @author Franziska Wuttig
     * @return Gibt die Id eines Highscores zurück.
     */
    public Long getId() {
        return id;
    }

    /**
     * @author Franziska Wuttig
     * @param id ID des Highscores.
     */
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof HighscoreEntity)) {
            return false;
        }
        HighscoreEntity other = (HighscoreEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "bws.datenmodell.HighscoresEntity[ id=" + id + " ]";
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt die Punkte eines Spielers zurück.
     */
    public int getPunkte() {
        return punkte;
    }

    /**
     * @author Franziska Wuttig
     * @param punkte Gesamtpunkte des Benutzers.
     */
    public void setPunkte(int punkte) {
        this.punkte = punkte;
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt den Spieler zurück.
     */
    public NutzerEntity getSpieler() {
        return spieler;
    }

    /**
     * @author Franziska Wuttig
     * @param spieler Der Benutzer der grade spielt.
     */
    public void setSpieler(NutzerEntity spieler) {
        this.spieler = spieler;
    }
}
