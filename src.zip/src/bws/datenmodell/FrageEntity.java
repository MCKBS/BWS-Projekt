package bws.datenmodell;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @Entity Annotation macht kenntlich, dass diese Klasse von JPA persistiert werden soll.
 * @Table ordnet die Entitätsklasse der gleichnamigen Tabelle in der Datenbank zu.
 * 
 * @author Franziska Wuttig
 */
@Entity
@Table(name = "frage")
public class FrageEntity implements Serializable {
    
    /**
     * Konstruktor der Klasse
     * 
     * @author Franziska Wuttig
     */
    public FrageEntity() {
        
    }

    private static final long serialVersionUID = 1L;
    
    /**
     * @Id kennzeichnet den Primärschlüssel
     * @GeneratedValue bedeutet, dass dieser automatisch generiert werden soll
     */
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    /**
     * @Column passt die Zuordnung zwischen dem Entitätsattribut und der Datenbankspalte an.
     * columnDefinition definiert ein SQL-Fragment, das während der Tabellendefinition verwendet wird.
     * nullable legt fest, das diese Datenbankspalte nicht null, also nicht leer sein darf.
     * length legt die Länge fest, die der Inhalt der Datenbankspalte haben darf.
     */
    @Column(columnDefinition = "text", nullable = false, length = 100)
    /**
     * Spalte Frage der Tabelle Frage. Enthält die Frage als String.
     */
    private String frage;

    /**
     * @Column passt die Zuordnung zwischen dem Entitätsattribut und der Datenbankspalte an.
     * columnDefinition definiert ein SQL-Fragment, das während der Tabellendefinition verwendet wird.
     * nullable legt fest, das diese Datenbankspalte nicht null, also nicht leer sein darf.
     * length legt die Länge fest, die der Inhalt der Datenbankspalte haben darf.
     */
    @Column(columnDefinition = "text", nullable = false, length = 100)
    /**
     * Spalte Antwort der Tabelle Frage. Enthält die Antwort als String.
     */
    private String antwort;

     /**
     * @Column passt die Zuordnung zwischen dem Entitätsattribut und der
     * Datenbankspalte an. columnDefinition definiert ein SQL-Fragment, das
     * während der Tabellendefinition verwendet wird. nullable legt fest, das
     * diese Datenbankspalte nicht null, also nicht leer sein darf.
     */
    @Column(columnDefinition = "text", nullable = false)
    /**
     * Spalte Karte der Tabelle Frage.
     * Enthält die Bezeichung der Karte als String (Deutschland-,
     * Europa- oder Weltkarte).
     */
    private String karte;

    /**
     * @Column passt die Zuordnung zwischen dem Entitätsattribut und der Datenbankspalte an.
     * columnDefinition definiert ein SQL-Fragment, das während der Tabellendefinition verwendet wird.
     * nullable legt fest, das diese Datenbankspalte nicht null, also nicht leer sein darf.
     */
    @Column(columnDefinition = "text", nullable = false)
    /**
     * Die Höhen- und Breitengrade zu der Antwort der Frage.
     */
    private String latLng;

    /**
     * @author Franziska Wuttig
     * @return Gibt die Id einer Frage zurück.
     */
    public Long getId() {
        return id;
    }

    /**
     * @author Franziska Wuttig
     * @param id ID der Frage.
     */
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FrageEntity)) {
            return false;
        }
        FrageEntity other = (FrageEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "bws.datenmodell.FrageEntity[ id=" + id + " ]";
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt die Frage zurück.
     */
    public String getFrage() {
        return frage;
    }

    /**
     * @author Franziska Wuttig
     * @param titel Die eigentliche Frage.
     */
    public void setFrage(String titel) {
        this.frage = titel;
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt die Antwort zurück.
     */
    public String getAntwort() {
        return antwort;
    }

    /**
     * @author Franziska Wuttig
     * @param antwort Die Antwort der Frage.
     */
    public void setAntwort(String antwort) {
        this.antwort = antwort;
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt die Karte zurück.
     */
    public String getKarte() {
        return karte;
    }

    /**
     * @author Franziska Wuttig
     * @param karte Gibt die Spielkarte an.
     */
    public void setKarte(String karte) {
        this.karte = karte;
    }

    /**
     * @author Franziska Wuttig
     * @return Die Höhen- und Breitengrade der Antwort der Frage.
     */
    public String getLatLng() {
        return latLng;
    }

    /**
     * @author Franziska Wuttig
     * @param latLng Die Höhen- und Breitengrade der Antwort der Frage
     */
    public void setLatLng(String latLng) {
        this.latLng = latLng;
    }
}