package bws.datenmodell;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @Entity Annotation macht kenntlich, dass diese Klasse von JPA persistiert
 * werden soll.
 * @Table ordnet die Entitätsklasse der gleichnamigen Tabelle in der Datenbank
 * zu.
 *
 * @author Franziska Wuttig
 */
@Entity
@Table(name = "nutzer")
public class NutzerEntity implements Serializable {

    private static long serialVersionUID = 1L;

    /**
     * @Id kennzeichnet den Primärschlüssel
     * @GeneratedValue bedeutet, dass dieser automatisch generiert werden soll
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

     /**
     * @Column passt die Zuordnung zwischen dem Entitätsattribut und der Datenbankspalte an.
     * unique legt fest, dass der Inhalt der Datenbankspalte nur einmal vorkommen darf.
     * length legt die Länge fest, die der Inhalt der Datenbankspalte haben darf.
     */
    @Column(unique = true, length = 50)
    /**
     * Spalte username der Tabelle Nutzer. Enthält den Benutzernamen eines Nutzers.
     */
    private String username;

    /**
     * Spalte password der Tabelle Nutzer. Enthält das verschlüsselte Passwort eines Benutzers.
     */
    private byte[] password;

    /**
     * @Column passt die Zuordnung zwischen dem Entitätsattribut und der Datenbankspalte an.
     * columnDefinition definiert ein SQL-Fragment, das während der Tabellendefinition verwendet wird.
     */
    @Column(columnDefinition = "text")
    /**
     * Spalte rolle der Tabelle Nutzer. Enthält die Rolle eines Nutzers. False bedeutet Spieler und true bedeutet Admin.
     */
    private boolean rolle = false;

    /**
     * @Column passt die Zuordnung zwischen dem Entitätsattribut und der Datenbankspalte an.
     * columnDefinition definiert ein SQL-Fragment, das während der Tabellendefinition verwendet wird.
     */
    @Column(columnDefinition = "text")
    /**
     * Spalte gesperrt der Tabelle Nutzer. Enthält die Aktivität (gesperrt oder frei) eines Nutzers. True bedeutet gesperrt und false bedeutet
     * frei.
     */
    private boolean gesperrt = true;

    
    @OneToMany(mappedBy = "spieler", cascade = CascadeType.REMOVE)
    private List<HighscoreEntity> highscores;

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (getId() != null ? getId().hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof NutzerEntity)) {
            return false;
        }
        NutzerEntity other = (NutzerEntity) object;
        if ((this.getId() == null && other.getId() != null) || (this.getId() != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return getUsername() + " " + isRolle() + " " + isGesperrt();
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt die Id eines Nutzers zurück.
     */
    public Long getId() {
        return id;
    }

    /**
     * @author Franziska Wuttig
     * @param id ID des Nutzers.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt den Username eines Nutzers zurück.
     */
    public String getUsername() {
        return username;
    }

    /**
     * @author Franziska Wuttig
     * @param username Benutzername eines Benutzers.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt das Passwort eines Nutzers zurück.
     */
    public byte[] getPassword() {
        return password;
    }

    /**
     * @author Franziska Wuttig
     * @param password Passwort des Benutzers.
     */
    public void setPassword(byte[] password) {
        this.password = password;
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt die Rolle eines Nutzers als Boolean zurück.
     */
    public boolean isRolle() {
        return rolle;
    }

    /**
     * @author Franziska Wuttig
     * @param rolle Die Rolle des Benutzers.
     */
    public void setRolle(boolean rolle) {
        this.rolle = rolle;
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt die Aktivität eines Benutzers als Boolean zurück.
     */
    public boolean isGesperrt() {
        return gesperrt;
    }

    /**
     * @author Franziska Wuttig
     * @param gesperrt Booleanwert ob der Benutzer gesperrt ist oder nicht.
     */
    public void setGesperrt(boolean gesperrt) {
        this.gesperrt = gesperrt;
    }

    /**
     * @author Franziska Wuttig
     * @return Gibt eine Liste aller Highscores zurück.
     */
    public List<HighscoreEntity> getHighscores() {
        return highscores;
    }

    /**
     * @author Franziska Wuttig
     * @param highscores Eine Liste aller Highscores
     */
    public void setHighscores(List<HighscoreEntity> highscores) {
        this.highscores = highscores;
    }
}
